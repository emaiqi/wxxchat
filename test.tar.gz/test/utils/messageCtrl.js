require("../protobuf/ByteBufferAB.min.js");
require("../protobuf/Long.min.js");

var websocket = require('./websocket.js');
var ProtoBuf = require("../protobuf/protobuf.js");

var util = require('./util.js');
var Map = require('./map.js');



// (function(){

var MessageCtrl = { map :new Map() , isOpen : false};

    // MessageCtrl.callBack = new map();
    // 连接服务器
    MessageCtrl.onConnectSocket = function()
    {
        var that = this;
        wx.connectSocket({
            url:'wss://ddz.blingstorm.com.cn:8088/ws'
        })
        wx.onSocketOpen(function (res) {
            that.isOpen = true;
            console.log('WebSocket连接已打开！')
        })
        wx.onSocketError(function(res){
            console.log('WebSocket连接打开失败，请检查！')
        })
        wx.onSocketMessage(MessageCtrl.onSocketMessage)
    }

    // 发送协议
    // msg:协议json
    //id ，消息的协议号
    MessageCtrl.sendMessage = function (msg) {
        var id = msg.cmd + "";
        delete msg.cmd;
        console.log(util.formatTime(new Date(Date.now())) + " 发送消息" + id);
        var msgStr = id + "=" + JSON.stringify(msg)
        console.log("传输 消息 = " + msgStr);
        wx.sendSocketMessage({ data: msgStr });
    },

    // 服务器回调接口
    MessageCtrl.onSocketMessage = function (res) {
            var resopnseMessage = res.data.split("=");
                if (resopnseMessage.length == 2) {
                    var id = resopnseMessage[0];
                    var jsonMsg = JSON.parse(resopnseMessage[1]);
                    console.log("收到消息 id = " + id + " , message =" + JSON.stringify(jsonMsg));
                    var responseCallBack = MessageCtrl.map.get(id);
                    if (responseCallBack != null && responseCallBack.length > 0)
                    { 
                        for (var i = 0; i < responseCallBack.length; i++)
                            responseCallBack[i](jsonMsg);
                    }    
                }
         },

    /**
     *增加消息回调
     *  */
    MessageCtrl.addResopnseCallBack = function (id, callback) {
        MessageCtrl.map.put(id, callback);
        console.log("成功加入 ID" + id + " 当前key num =" + MessageCtrl.map.keys.length);
        },
     /**
     *移除消息回调
     *  */    
    MessageCtrl.removeResopnseCallBack = function (id, callBack) { 
        if (arguments.length == 1)
            MessageCtrl.map.removeKey(arguments[0]);
        else
            MessageCtrl.map.removeValues(id, callBack);
        console.log("成功移除 ID" + id + " 当前key num =" + MessageCtrl.map.keys.length);
    },

    // 读取协议文件
    // protoName:协议名称
    // className:协议类型
    MessageCtrl.getProtoBuf = function(protoName, className)
    {
        var content = MessageCtrl.getFormateStr(ProtoBuf.Util.fetch("./protos/"+protoName))
        var json = ProtoBuf.loadJson(JSON.parse(contents));


        var tmp = ProtoBuf.loadProto(content).build(className);
        var msg = new tmp()
        return msg;
    },

    //wx将文件加壳，主要将导出的string串格式化（去除外壳）
    MessageCtrl.getFormateStr = function(str)
    {
        var last = str.lastIndexOf("})");
        var first = str.indexOf("history,Caches;");
        var newStr = str.substring(first + 15,last);
        return newStr;
    }

module.exports = {
    //连接服务器
    onConnectSocket:MessageCtrl.onConnectSocket,
    //发送消息
    sendMessage:    MessageCtrl.sendMessage,
    //获取数据
    getProtoBuf:    MessageCtrl.getProtoBuf,
    addResopnseCallBack: MessageCtrl.addResopnseCallBack,
    removeResopnseCallBack:MessageCtrl.removeResopnseCallBack,
   
}