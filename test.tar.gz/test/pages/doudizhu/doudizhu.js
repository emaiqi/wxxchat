// var ResourceData = require('./demo/ResourceData.js');
// var Prototype = require('./demo/Prototype.js');
var JMain = require( '../../demo/JControls.js' ).getJMain();
 var DJDDZ = require('../../demo/DJDDZ.js')
var fileCtrl = require("../../utils/fileCtrl.js");
var ResData = require("../../demo/ResourceData.js")
var app = getApp();

var GameState = {
    COMEIN_GAME: 0, //进入游戏，到发牌结束
    JIAODIZHU: 1,  //叫地址
    QIANDIZHU: 2 ,   //抢地主
    JIABEI: 3,     //加倍
    BEGIN_GAME: 4, //开始游戏
    END_GAME : 10, //游戏结束（看需求，是否应该清空玩家信息））
};
//测试
var tempData = {
    param1: 'ac',
    param2: 34,
    templateName:'',
    backFun:'',
    count: 1
}

Page( {
    state: GameState.COMEIN_GAME,  //游戏状态  
    RoomPos: 0, //服务器房间中自己的pos （在游戏中中自己的位置永远是 1）    
    PlayerOpenId: {2: '', 3: ''}, //把游戏中的位置和opendID相对应，以便查找位置 
    data: {
        toastHidden: true,
        displayJiqiren: false,  //机器人图标显示
        displayRight: true,    //右部头像类型显示
        displayLeft: true,   //左部头像类型显示
        displayDZIcon:false,    //地主图标的显示
        hiddenSelfPlay: true,   //自己出牌提示隐藏
        hiddenPass: false,  //不出隐藏
        displayMiddle: false,   //中部UI布局的显示和隐藏
        displayJiaodizhu: false, //显示叫地主，抢地主，加倍的按钮
        displayChupai: false,//显示出牌时候的按钮
        displayPipei: true,//显示匹配按钮
        BGM:"http://e.blingstorm.com.cn:8300/ppm/static/admin/dou/audio/doudizhuBG.mp3",    //背景音乐地址
        BGMAction: {    //背景音乐播放动作
            method: 'play'
        },
        myScore:100,    //自己分数
        leftScore:100,  //左对手分数
        rightScore:123, //右对手分数
        baseScore:100,  //本局底分?底价
        double:5,     //翻倍数

        //模板测试
        templateView: "template1",
        templateData: tempData,
        //测试end

    },
    //测试
    myCount: 0,

    UIData: {
        light: ""
        ,topBg:""
        ,bottomBg:""
        ,bei:""
        ,buchu:""
        ,chupai:""
        ,di:""
        ,dizhu:""
        ,fen:""
        ,heidi:""
        ,jifen:""
        ,jiqiren:""
        ,liaotian:""
        ,shezhi:""
        ,tishi:""
        ,toukuang1:""
        ,toukuang2:""
        ,touxiangdi:""
        ,tuichu:""
        ,zhong:""
    },
    onLoad: function () {
        //注册消息
        app.message.addResopnseCallBack(40002, this.BattleMatchResponse);//匹配返回
        app.message.addResopnseCallBack(40036, this.PlayInfoResponse);  //返回玩家信息
        app.message.addResopnseCallBack(40040, this.DealPokerResponse); //服务器下发初始的牌
        app.message.addResopnseCallBack(40044, this.WhoCallTheLandlord); //服务器下发谁改抢地址
        app.message.addResopnseCallBack(40038, this.callTheLandlord); //服务器下发是否叫地址，抢地主，加倍
        app.message.addResopnseCallBack(40019, this.PlayCardResponse);//服务器广播玩家所出的牌

        var that = this
  	//调用应用实例的方法获取全局数据
        getApp().getUserInfo(function (userInfo) {
            //更新数据
            that.setData({
                userInfo: userInfo
            })
            that.update()
        });
        this.initGame();
    },
    initGame: function() {
        console.log( "initGame begin" )
        this.initUI();
        var DJDDZ = require( '../../demo/DJDDZ.js' )
        DJDDZ.Init( "canvas1" );
        console.log( "initGame end..." )
    },
    initUI: function()
    {
        for(var p in this.UIData)
        {
            var key = ResData.Images[p].path;
            var obj = {};
            obj[p] = fileCtrl.getFilePathByKey(key);
            this.setData(obj)
        }
    },


    onClick: function( event ) {
        console.log( event );
        var x = event.detail.x - event.currentTarget.offsetLeft;
        var y = event.detail.y - event.currentTarget.offsetTop;

        JMain.JForm.mousePosition = {x:x, y: y}
        JMain.JForm.onControlClick.call( JMain.JForm );
        
        //模板测试
        this.myCount += 1
        var count = this.myCount%2 + 1;
        var tmp = {};

        tempData.templateName = "template" + count;
        tempData.backFun = "template"+count+"Call"
        tempData.param1 = "ac1"
        tempData.count = count


        this.setData({
            templateView: "template" + count,
            templateData:tempData
        })
        //测试end

    },

    template1Call: function()
    {
        console.log("this is template1Call 11111 ");
    },

    template2Call: function()
    {
        console.log("this is template2Call 222222 ");
    },
    /**
     *当前的OpenID 是否为自己的openID
     */
    isSelfOpenID: function (openId) { 
        return openId == app.globalData.userToken;
    },
    /**
     *根据openId获取玩家在游戏中的位置（自己为1 ，右为 2，左为 3 逆时针）
     */
    getGamePosByOpenId: function (openId) { 
        if (isSelfOpenID)
            return 1;    
        return this.PlayerOpenId[2] == openId ? 2 : 3;
    },

//********************************************点击事件的处理*****************************************************
    // 发牌结束
    onDealingOver: function()
    {
        this.setData({
            displayJiaodizhu:true
        })
    },

    //不出
    onClickPass: function()
    {
        console.log("onPressPass");
        DJDDZ.onClickPass();
    },
    //提示
    onClickTips:function()
    {
        console.log("onClickTips");
        DJDDZ.onClickTips()
    },
    // 出牌
    onClickPlay: function()
    {
        console.log("onClickPlay");
        DJDDZ.onClickPlay()
    },

    // 
    //1、自己出牌 2、右边出牌，3左边出牌
    onPlay: function(playId, showPass)
    {   
        this.setData({
            hiddenSelfPlay:playId!=1, 
            hiddenPass:!showPass
        })
    },
    // 显示错误提示
    setToastHidden: function()
    {
        this.setData({toastHidden:false})
    },
    // 显示错误之后delay一段时间自动调用
    toastChange: function()
    {
         this.setData({toastHidden:true});
    },
    /**
     *点击随机匹配按钮
     */
    onClickMatch: function () { 
        //TODO
        //点击匹配，单机直接发牌,跳过叫、抢地主过程
        // DJDDZ.onStartDealing();

        // console.log("onClickMatch");

        // return;
        //发送匹配消息
        let msg = {
            "cmd": 40001,
            "openId": getApp().globalData.userToken
        }
        app.message.sendMessage(msg);
        this.setData({
            displayPipei : false
        })
    },
    /**
     *点击好友匹配按钮
     */
    onClickMatchWithFriends: function () { 
        console.log("onClickMatchWithFriends");
    },

//**************************************************服务返回的消息*********************************************************   
    /**
     *随机匹配消息的返回
     */
    BattleMatchResponse: function (response) { 
        console.log("BattleMatchResponse");
        if (response.state != 0) { 
            //重新显示 邀请好友的信息
            this.setData({
                displayPipei : false
            })
        }  
    },
    /**
     *服务器广播玩家信息
     */
    PlayInfoResponse: function (response) { 
        console.log('PlayInfoResponse');
        for (var i = 0; i < response.player.length; i++){
            if (response.player[i].openId != app.globalData.userToken){ 
                app.globalData.playerInfo[response.player[i].openId] = response.player[i];
            }
        }
        //显示玩家信息
        
    },
    /**
     *服务器下发发牌信息
     */
    DealPokerResponse : function (response){
        var hiddenPokers = response.hiddenPokers; //三张底牌
        var selfPoker; //自己的牌
        for (var i = 0; i < response.playerPoker.length; i++){
            if (playerPoker[i].openid == app.globalData.userToken)
            { 
                selfPoker = playerPoker[i].pokers.concat();
                break ;
            }    
        }
        
    },
    /**
     *服务器广播谁该叫地主了
     *   */
    WhoCallTheLandlord: function (response) { 
        if (this.isSelfOpenID(response.openId))
        { 
            //显示叫地主按钮

        }    
        this.state = GameState.JIAODIZHU;
    },
    /**
     *服务器广播 其他人 是否叫地主，抢地主，加倍
     */
    callTheLandlord: function (response) { 
        if (response.callType == 1) {   //叫地址
            console.log("叫地主");
            
            if (this.isSelfOpenID(response.openId))
            { 
              //在自己的区域显示 “叫地主" 文字  

            }
            else if (this.isSelfOpenID(response.nextOpenId)) { 
                if (response.isTrue) {
                    //显示抢地主的按钮
                }
                else { 
                    //显示叫地主的按钮
                }
                
            }
        }
        else if (response.callType == 2) { //抢地址
            console.log("抢地址");
            if (this.isSelfOpenID(response.openId)) {
                //在自己的区域显示 “叫地主" 文字  

            }
            else if (this.isSelfOpenID(response.nextOpenId)) { 
                //显示抢地主的按钮
            }
        }
        else if (response.callType == 3) { //加倍
            console.log("加倍");
            //清空 区域内的 “叫地主" 文字 ,显示底牌 显示加倍按钮
        }
    },
    PlayCardResponse: function (response) { 
        var pos = getGamePosByOpenId(response.playerPoker.openid);
        // 在 pos 位置显示 牌的信息 ，同时也要删除pos 位置的玩家手牌中的信息 
        //更新玩家手牌数目， 更新倍数
    },




})






