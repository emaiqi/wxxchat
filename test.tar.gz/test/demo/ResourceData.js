
var ResourceData= {
    Images:{
        //path：文件相对路径，picNum:当前图片中宽和高包含的小图片数，cellSize:小图片的宽和高，data：存放加载的图片数据。
        //goddess_new:{path:"images/goddess_new.png", picNum:{WNum:4,HNum:4},cellSize:{width:32,height:48}, data:null}
        1:{path:"img/1.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:17}
        ,2:{path:"img/2.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:16}
        ,3:{path:"img/3.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:3}
        ,4:{path:"img/4.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:4}
        ,5:{path:"img/5.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:5}
        ,6:{path:"img/6.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:6}
        ,7:{path:"img/7.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:7}
        ,8:{path:"img/8.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:8}
        ,9:{path:"img/9.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:9}
        ,10:{path:"img/10.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:10}
        ,11:{path:"img/11.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:11}
        ,12:{path:"img/12.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:12}
        ,13:{path:"img/13.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:13}
        ,14:{path:"img/14.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:14}
        ,15:{path:"img/15.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:4,num:15}
        ,16:{path:"img/16.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:3}
        ,17:{path:"img/17.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:4}
        ,18:{path:"img/18.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:5}
        ,19:{path:"img/19.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:6}
        ,20:{path:"img/20.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:7}
        ,21:{path:"img/21.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:8}
        ,22:{path:"img/22.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:9}
        ,23:{path:"img/23.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:10}
        ,24:{path:"img/24.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:11}
        ,25:{path:"img/25.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:12}
        ,26:{path:"img/26.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:13}
        ,27:{path:"img/27.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:14}
        ,28:{path:"img/28.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:3,num:15}
        ,29:{path:"img/29.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:3}
        ,30:{path:"img/30.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:4}
        ,31:{path:"img/31.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:5}
        ,32:{path:"img/32.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:6}
        ,33:{path:"img/33.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:7}
        ,34:{path:"img/34.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:8}
        ,35:{path:"img/35.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:9}
        ,36:{path:"img/36.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:10}
        ,37:{path:"img/37.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:11}
        ,38:{path:"img/38.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:12}
        ,39:{path:"img/39.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:13}
        ,40:{path:"img/40.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:14}
        ,41:{path:"img/41.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:2,num:15}
        ,42:{path:"img/42.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:3}
        ,43:{path:"img/43.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:4}
        ,44:{path:"img/44.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:5}
        ,45:{path:"img/45.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:6}
        ,46:{path:"img/46.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:7}
        ,47:{path:"img/47.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:8}
        ,48:{path:"img/48.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:9}
        ,49:{path:"img/49.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:10}
        ,50:{path:"img/50.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:11}
        ,51:{path:"img/51.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:12}
        ,52:{path:"img/52.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:13}
        ,53:{path:"img/53.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:14}
        ,54:{path:"img/54.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null,se:1,num:15}
        ,BeiMian:{path:"img/BeiMian.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:105,height:150}, data:null}
        ,bg1:{path:"img/beijing.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:640,height:1136}, data:null}
        ,btn:{path:"img/btn.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:469,height:204}, data:null}
        ,api:{path:"img/icon_API_HL.png", picNum:{WNum:1,HNum:1},cellSize:{width:40,height:40}, data:null}
        ,component:{path:"img/icon_component_HL.png", picNum:{WNum:1,HNum:1},cellSize:{width:40,height:40}, data:null}
        ,wechat:{path:"img/wechatHL.png", picNum:{WNum:1,HNum:1},cellSize:{width:40,height:40}, data:null}

        ,light:{path:"img/1.png", picNum:{WNum:1,HNum:1},cellSize:{width:638,height:225}, data:null}
        ,topBg:{path:"img/2.png", picNum:{WNum:1,HNum:1},cellSize:{width:415,height:86}, data:null}
        ,bottomBg:{path:"img/3.png", picNum:{WNum:1,HNum:1},cellSize:{width:640,height:128}, data:null}
        ,bei:{path:"img/bei.png", picNum:{WNum:1,HNum:1},cellSize:{width:45,height:45}, data:null}
        ,buchu:{path:"img/buchu.png", picNum:{WNum:1,HNum:1},cellSize:{width:149,height:70}, data:null}
        ,chupai:{path:"img/chupai.png", picNum:{WNum:1,HNum:1},cellSize:{width:149,height:70}, data:null}
        ,di:{path:"img/di.png", picNum:{WNum:1,HNum:1},cellSize:{width:45,height:45}, data:null}
        ,dizhu:{path:"img/dizhu.png", picNum:{WNum:1,HNum:1},cellSize:{width:56,height:56}, data:null}
        ,fen:{path:"img/fen.png", picNum:{WNum:1,HNum:1},cellSize:{width:45,height:45}, data:null}
        ,heidi:{path:"img/heidi.png", picNum:{WNum:1,HNum:1},cellSize:{width:163,height:36}, data:null}
        ,jifen:{path:"img/jifen.png", picNum:{WNum:1,HNum:1},cellSize:{width:152,height:39}, data:null}
        ,jiqiren:{path:"img/jiqiren.png", picNum:{WNum:1,HNum:1},cellSize:{width:48,height:49}, data:null}

        ,black_1:{path:"img/black_A.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_2:{path:"img/black_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_3:{path:"img/black_3.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_4:{path:"img/black_4.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_5:{path:"img/black_5.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_6:{path:"img/black_6.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_7:{path:"img/black_7.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_8:{path:"img/black_8.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_9:{path:"img/black_9.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_10:{path:"img/black_10.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_11:{path:"img/black_J.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_12:{path:"img/black_Q.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_13:{path:"img/black_K.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_1:{path:"img/red_A.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_2:{path:"img/red_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_3:{path:"img/red_3.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_4:{path:"img/red_4.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_5:{path:"img/red_5.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_6:{path:"img/red_6.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_7:{path:"img/red_7.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_8:{path:"img/red_8.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_9:{path:"img/red_9.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_10:{path:"img/red_10.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_11:{path:"img/red_J.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_12:{path:"img/red_Q.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_13:{path:"img/red_K.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,card:{path:"img/card.png", picNum:{WNum:1,HNum:1},cellSize:{width:128,height:168}, data:null}
        ,fangpian:{path:"img/fangpian.png", picNum:{WNum:1,HNum:1},cellSize:{width:70,height:66}, data:null}
        ,hongtao:{path:"img/hongtao.png", picNum:{WNum:1,HNum:1},cellSize:{width:70,height:66}, data:null}
        ,heitao:{path:"img/heitao.png", picNum:{WNum:1,HNum:1},cellSize:{width:70,height:66}, data:null}
        ,caohua:{path:"img/caohua.png", picNum:{WNum:1,HNum:1},cellSize:{width:70,height:66}, data:null}
        ,black_JOKER:{path:"img/black_JOKER.png", picNum:{WNum:1,HNum:1},cellSize:{width:26,height:149}, data:null}
        ,black_dizhu:{path:"img/black_dizhu.png", picNum:{WNum:1,HNum:1},cellSize:{width:26,height:149}, data:null}
        ,red_JOKER:{path:"img/red_JOKER.png", picNum:{WNum:1,HNum:1},cellSize:{width:77,height:108}, data:null}
        ,red_dizhu:{path:"img/red_dizhu.png", picNum:{WNum:1,HNum:1},cellSize:{width:77,height:108}, data:null}

        ,liaotian:{path:"img/liaotian.png", picNum:{WNum:1,HNum:1},cellSize:{width:60,height:61}, data:null}
        ,shezhi:{path:"img/shezhi.png", picNum:{WNum:1,HNum:1},cellSize:{width:48,height:49}, data:null}
        ,tishi:{path:"img/tishi.png", picNum:{WNum:1,HNum:1},cellSize:{width:149,height:70}, data:null}
        ,toukuang1:{path:"img/toukuang1.png", picNum:{WNum:1,HNum:1},cellSize:{width:133,height:133}, data:null}
        ,toukuang2:{path:"img/toukuang2.png", picNum:{WNum:1,HNum:1},cellSize:{width:133,height:133}, data:null}
        ,touxiangdi:{path:"img/touxiangdi.png", picNum:{WNum:1,HNum:1},cellSize:{width:123,height:123}, data:null}
        ,tuichu:{path:"img/tuichu.png", picNum:{WNum:1,HNum:1},cellSize:{width:56,height:57}, data:null}
        ,zhong:{path:"img/zhong.png", picNum:{WNum:1,HNum:1},cellSize:{width:146,height:146}, data:null}
    },
    Sound:{
        //soundName:声音文件名称，path：文件夹相对路径，data：存放加载的声音数据。由于各种浏览器对声音格式的支持不一致，声音文件格式有MP3和OGG两种
        //sound01:{soundName:"sound01",path:"sound/", data:null,num:17}
    },
    Animation:{
         //ZS1_move:{imageName:"goddess_new",beginPoint:{WNum:0,HNum:0},allPlayNum:4,times:2}
    },

    SelfPokerSize:{width:105,height:150}

};

module.exports = ResourceData