// "use strict";

// var ResourceData = require('./demo/ResourceData.js');
// var Prototype = require('./demo/Prototype.js');
var JMain = require( '../../demo/JControls.js' ).getJMain();
 var DJDDZ = require('../../demo/DJDDZ.js')
var fileCtrl = require("../../utils/fileCtrl.js");
var ResData = require("../../demo/ResourceData.js")
var util = require("../../utils/util.js")
var app = getApp();

var GameState = {
    COMEIN_GAME: 0, //进入游戏，到发牌结束
    JIAODIZHU: 1,  //叫地址
    QIANDIZHU: 2 ,   //抢地主
    JIABEI: 3,     //加倍
    BEGIN_GAME: 4, //开始游戏
    END_GAME : 10, //游戏结束（看需求，是否应该清空玩家信息））
};
//测试
var tempData = {
    param1: 'ac',
    param2: 34,
    templateName:'',
    backFun:'',
    count: 1
}

Page( {
    state: GameState.COMEIN_GAME,  //游戏状态  
    RoomPos: 0, //服务器房间中自己的pos （在游戏中中自己的位置永远是 1）    
    PlayerOpenId: {1: app.globalData.userToken, 2: '', 3: '' }, //把游戏中的位置和opendID相对应，以便查找位置 
    PlayerInfo: {}, //存储玩家信息，key 是 openId
    DiZhuOpenId:"", //地主的openID
    data: {
        toastHidden: true,
        displayJiqiren: false,  //机器人图标显示
        displayRight: true,    //右部头像类型显示
        displayLeft: true,   //左部头像类型显示
        displayDZIcon:false,    //地主图标的显示
        displaySelfPlay: false,   //自己出牌提示隐藏
        hiddenPass: false,  //不出隐藏
        displayMiddle: true,   //中部UI布局的显示和隐藏
        displayJiaodizhu: false, //显示叫地主，抢地主，加倍的按钮
        displayChupai: false,//显示出牌时候的按钮
        displayPipei: false,//显示匹配按钮
        BGM:"http://e.blingstorm.com.cn:8300/ppm/static/admin/dou/audio/doudizhuBG.mp3",    //背景音乐地址
        BGMAction: {    //背景音乐播放动作
            method: 'play'
        },
        rightPlayer: "",
        rightPlayerInfo: { isShow: false }, //右边玩家信息
        leftPlayer: "",
        leftPlayerInfo: {isShow: false} , //左侧玩家信息

        myScore:0,    //自己分数
        leftScore:100,  //左对手分数
        rightScore:123, //右对手分数
        baseScore:100,  //本局底分?底价
        doubleTimes:5,     //翻倍数

        //模板测试
        templateView: "template1",
        templateData: tempData,
        //测试end

    },
    //测试
    myCount: 0,

    
    onLoad: function () {
        //注册消息
        app.message.addResopnseCallBack(40002, this.BattleMatchResponse);//匹配返回
        app.message.addResopnseCallBack(40036, this.PlayInfoResponse);  //返回玩家信息
        app.message.addResopnseCallBack(40040, this.DealPokerResponse); //服务器下发初始的牌
        app.message.addResopnseCallBack(40044, this.WhoCallTheLandlord); //服务器下发谁改抢地址
        app.message.addResopnseCallBack(40038, this.callTheLandlord); //服务器下发是否叫地址，抢地主，加倍
        app.message.addResopnseCallBack(40019, this.PlayCardResponse);//服务器广播玩家所出的牌
        app.message.addResopnseCallBack(40045, this.StartPlayCardResponse);//服务器广播局内开始

        this.setUserInfo();
        this.initGame();
    },
    initGame: function() {
        console.log( "initGame begin" )
        this.initUI();
        var DJDDZ = require( '../../demo/DJDDZ.js' )
        DJDDZ.Init( "canvas1" );
        console.log( "initGame end..." )
    },
    initUI: function()
    {
        for(var p in ResData.UI)
        {
            var key = ResData.UI[p].path;
            var obj = {};
            obj[p] = fileCtrl.getFilePathByKey(key);
            this.setData(obj)
        }
    },


    onClick: function( event ) {
        console.log( event );
        var x = event.detail.x - event.currentTarget.offsetLeft;
        var y = event.detail.y - event.currentTarget.offsetTop;

        JMain.JForm.mousePosition = {x:x, y: y}
        JMain.JForm.onControlClick.call( JMain.JForm );
        
        //模板测试
        // this.myCount += 1
        // var count = this.myCount%2 + 1;
        // var tmp = {};

        // tempData.templateName = "template" + count;
        // tempData.backFun = "template"+count+"Call"
        // tempData.param1 = "ac1"
        // tempData.count = count


        // this.setData({
        //     templateView: "template" + count,
        //     templateData:tempData
        // })
        //测试end

    },

    template1Call: function()
    {
        console.log("this is template1Call 11111 ");
    },

    template2Call: function()
    {
        console.log("this is template2Call 222222 ");
    },
    /**
     *当前的OpenID 是否为自己的openID
     */
    isSelfOpenID: function (openId) { 
        return openId == app.globalData.userToken;
    },
    /**
     *根据openId获取玩家在游戏中的位置（自己为1 ，右为 2，左为 3 逆时针）
     */
    getGamePosByOpenId: function (openId) { 
        if (this.isSelfOpenID(openId))
            return 1;    
        return this.PlayerOpenId[2] == openId ? 2 : 3;
    },
    /**
     *设置玩家基本信息
     */
    setUserInfo: function () { 
        var that = this;

  	    //调用应用实例的方法获取全局数据
        app.getUserInfo(function (userInfo) {
            //更新数据
            that.setData({
                userInfo: userInfo
            })
        });
        this.setData({
            myScore: app.globalData.userInfo.score,

        });
    },

//********************************************点击事件的处理*****************************************************
    /**
     *点击随机匹配按钮
     */
    onClickMatch: function () { 
        //TODO
         if(getApp().globalData.isSingle){
            //点击匹配，单机直接发牌,跳过叫、抢地主过程
            DJDDZ.onStartDealing();
            this.setData({
                displayPipei : false
            })

            this.setData({
                    rightPlayerInfo: {
                        isShow: true,
                        toukuang1: this.data.toukuang1,
                        avatarUrl: "",
                        fen: this.data.icon_jifen,
                        heidi: this.data.heidi,
                        score: 100,
                        nickName: "张三"
                    },
                    rightPlayer: "rightPlayer"
                });

                this.setData({
                    leftPlayerInfo: {
                        isShow: true,
                        toukuang2: this.data.toukuang2,
                        avatarUrl: "",
                        fen: this.data.icon_jifen,
                        heidi: this.data.heidi,
                        score: 200,
                        nickName: "李四",
                    },
                    leftPlayer: "leftPlayer"
                });
            return;
         }
        //发送匹配消息
        
        let msg = {
            "cmd": 40001,
            "openId": getApp().globalData.userToken
        }
        app.message.sendMessage(msg);
        this.setData({
            displayPipei : false
        })
    },
    /**
     *点击好友匹配按钮
     */
    onClickMatchWithFriends: function () { 
        console.log("onClickMatchWithFriends");
    },

    /**
     *  发牌结束
     */
    onDealingOver: function()
    {
         if(getApp().globalData.isSingle){
            
            return;
        }
        this.setData({
            displayJiaodizhu:true
        })
        var msg = {
            "cmd": 40043
        }
        app.message.sendMessage(msg);
    },
    /**
     *点击不叫地主 ,不抢地主 ， 不加倍
     */
    onClickBujiaoDZ: function () { 
        var type = 1;
        if (this.state == GameState.JIAODIZHU) {
            console.log("不叫地主");
            type = 1;
        }
        else if (this.state == GameState.QIANDIZHU) {
            console.log("不抢地主");
            type = 2;
        }
        else if (this.state == GameState.JIABEI) { 
            console.log("不加倍");
            type = 3;
        }
        var msg = {
            "cmd": 40037,
            "callType" : type,
            "isTrue" : false,
        }
        app.message.sendMessage(msg);
        this.setData({
            displaySelfPlay:false,
            displayJiaodizhu : false
        });
    },
    /**
     *点击叫地主 ,抢地主 ，加倍
     */
    onClickJiaoDZ: function () { 
        var type = 1;
        if (this.state == GameState.JIAODIZHU) {
            console.log("叫地主");
            type = 1;
        }
        else if (this.state == GameState.QIANDIZHU) {
            console.log("抢地主");
            type = 2;
        }
        else if (this.state == GameState.JIABEI) { 
            console.log("加倍");
            type = 3;
        }
        var msg = {
            "cmd": 40037,
            "callType": type,
            "isTrue": true,
        }
        app.message.sendMessage(msg);
        this.setData({
            displaySelfPlay : false,
            displayJiaodizhu : false
        });
    },


    //不出
    onClickPass: function()
    {
        console.log("onPressPass");
        DJDDZ.onClickPass();
    },
    //提示
    onClickTips:function()
    {
        console.log("onClickTips");
        DJDDZ.onClickTips()
    },
    // 出牌
    onClickPlay: function()
    {
        console.log("onClickPlay");
        if(getApp().globalData.isSingle){
            DJDDZ.onClickPlay()
        }
        else
        {
            DJDDZ.onClickPlayCard();
        }
    },

    // 
    //1、自己出牌 2、右边出牌，3左边出牌
    //showPass: truetrue = 显示“不出”选项
    onPlay: function(playId, showPass)
    {   
        this.setData({
            displaySelfPlay:playId == 1, 
            displayChupai:playId == 1,
            hiddenPass:!showPass
        })
         if(getApp().globalData.isSingle){
            this.setData({
                displayChupai:true
            })
            return;
        }
    },
    // 显示错误提示
    setToastHidden: function()
    {
        this.setData({toastHidden:false})
    },
    // 显示错误之后delay一段时间自动调用
    toastChange: function()
    {
         this.setData({toastHidden:true});
    },

//**************************************************服务返回的消息*********************************************************   
    /**
     *随机匹配消息的返回
     */
    BattleMatchResponse: function (response) { 
        console.log("BattleMatchResponse");
        if (response.state != 0) { 
            //重新显示 邀请好友的信息
            this.setData({
                displayPipei : false
            })
        }  
    },
    /**
     *服务器广播玩家信息
     */
    PlayInfoResponse: function (response) { 
        console.log('PlayInfoResponse');
        for (var i = 0; i < response.playerInfos.length; i++){
            if (this.isSelfOpenID(response.playerInfos[i].openId)) {
                this.RoomPos = response.playerInfos[i].position;
            }
            else { 
                this.PlayerInfo[response.playerInfos[i].openId] = response.playerInfos[i];
            }
        }
        for (var x in this.PlayerInfo) { 
            var pos = util.getGamePosByRoomPos(this.RoomPos, this.PlayerInfo[x].position);
            this.PlayerOpenId[pos] = x;
            //显示右测玩家信息
            if (pos == 2) {
                this.setData({
                    rightPlayerInfo: {
                        isShow: true,
                        toukuang1: this.data.toukuang1,
                        avatarUrl: this.PlayerInfo[x].avatarUrl,
                        fen: this.data.icon_jifen,
                        heidi: this.data.heidi,
                        score: this.PlayerInfo[x].score,
                        nickName: this.PlayerInfo[x].nickName,
                        title:"",
                    },
                    rightPlayer: "rightPlayer"
                });
            }
            else if (pos == 3) {    //显示左侧玩家信息
                this.setData({
                    leftPlayerInfo: {
                        isShow: true,
                        toukuang2: this.data.toukuang2,
                        avatarUrl: this.PlayerInfo[x].avatarUrl,
                        fen: this.data.icon_jifen,
                        heidi: this.data.heidi,
                        score: this.PlayerInfo[x].score,
                        nickName: this.PlayerInfo[x].nickName,
                        title:"",
                    },
                    leftPlayer: "leftPlayer"
                });
            }
        }
        
        //显示玩家信息
        
    },
    /**
     *服务器下发发牌信息
     */
    DealPokerResponse : function (response){
        var hiddenPokers = response.hiddenPokers; //三张底牌
        var selfPoker; //自己的牌 1
        var leftPoker;  //左边人牌 3
        var rightPoker; //右边人牌 2

        var pokerList = {1:'', 2:'', 3:''}

        for (var i = 0; i < response.playerPoker.length; i++){
            pokerList[this.getGamePosByOpenId(response.playerPoker[i].openid )] = response.playerPoker[i].pokers.concat();
            // if (this.isSelfOpenID(response.playerPoker[i].openid ))
            // { 
            //     selfPoker = response.playerPoker[i].pokers.concat();
            //     break ;
            // }    
        }
         DJDDZ.DealingList(pokerList, hiddenPokers);
    },
    /**
     *服务器广播谁该叫地主了
     *   */
    WhoCallTheLandlord: function (response) { 
        if (this.isSelfOpenID(response.openId))
        { 
            //显示叫地主按钮
            this.setData({
                displayMiddle:true,
                displaySelfPlay: true,
                displayJiaodizhu: true,
                bujiaoDZ: this.data.button_m_bujiao,
                jiaoDZ: this.data.button_m_jiaodizhu,
            });
            console.log("displaySelfPlay = " + this.data.displaySelfPlay);
        }    
        this.state = GameState.JIAODIZHU;
    },
    /**
     *服务器广播 其他人 是否叫地主，抢地主，加倍
     */
    callTheLandlord: function (response) { 
        if (response.callType == 1) {   //叫地址
            console.log("叫地主 返回");
            
            if (this.isSelfOpenID(response.openId))
            {
                //在自己的区域显示 “叫地主" 文字  

            }
            else if (this.isSelfOpenID(response.nextOpenId)) { 
                if (response.isTrue) {
                    //显示抢地主的按钮
                    this.state = GameState.QIANDIZHU;
                    this.setData({
                        displayMiddle: true,
                        displaySelfPlay: true,
                        displayJiaodizhu: true,
                        bujiaoDZ: this.data.button_m_buqiang,
                        jiaoDZ: this.data.button_m_qiangdizhu,
                    });
                }
                else { 
                    //显示叫地主的按钮
                    this.setData({
                        displaySelfPlay: true,
                        displayJiaodizhu: true,
                        bujiaoDZ: this.data.button_m_bujiao,
                        jiaoDZ: this.data.button_m_jiaodizhu,
                    });
                }
            }
        //有人已经叫地主了，现在开始抢地址了
            if (response.isTrue && response.callType == 1 ) { 
                console.log("开始抢地主");
                this.state = GameState.QIANDIZHU;
            }
        }
        else if (response.callType == 2) { //抢地主
            console.log("抢地主");
            this.state = GameState.QIANDIZHU;
            if (this.isSelfOpenID(response.openId)) {
                //在自己的区域显示 “抢地主" 文字  
            
            }
            else if (this.isSelfOpenID(response.nextOpenId)) {
                //显示抢地主的按钮
                this.setData({
                    displaySelfPlay: true,
                    displayJiaodizhu: true,
                    bujiaoDZ: this.data.button_m_buqiang,
                    jiaoDZ: this.data.button_m_qiangdizhu,
                });
            }
            //判断地主是否已经出来了
            if (response.nextOpenId.length == 0 && response.landlordOpenId.length > 0) { 
                //可以确定 地主了
                this.DiZhuOpenId = response.landlordOpenId;
                //可以显示底牌了
                //设置地主帽了
                console.log("onGrabTheLandlord  " + response.landlordOpenId);
                DJDDZ.onGrabTheLandlord(this.getGamePosByOpenId(response.landlordOpenId))


                //开始设置 加倍按钮
                 this.state = GameState.JIABEI;
                 this.setData({
                     displaySelfPlay: true,
                     displayJiaodizhu: true,
                     bujiaoDZ: this.data.button_m_bujiabei,
                     jiaoDZ: this.data.button_m_jiabei,
                 });
            }
        }
        else if (response.callType == 3) { //加倍
            console.log("加倍");
            //清空 区域内的 “叫地主" 文字 ,显示底牌 显示加倍按钮
           
        }
        this.setData({
            doubleTimes: response.doubleTimes
        });
    },
    PlayCardResponse: function (response) { 
        var pos = this.getGamePosByOpenId(response.openid);
        var nextPos = this.getGamePosByOpenId(response.nextOpenId);
        // 在 pos 位置显示 牌的信息 ，同时也要删除pos 位置的玩家手牌中的信息 
        //更新玩家手牌数目， 更新倍数

        // DJDDZ.onResponsePlayCard = function( nowPos, nextPos, pokerList ) 
        DJDDZ.onResponsePlayCard(pos, nextPos, response.pokers);
    },

    //可以开始出牌
    StartPlayCardResponse : function(response)
    {
        DJDDZ.onStartPlay()
    }




})






