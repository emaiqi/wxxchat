//setting.js

var app = getApp();

var setting = {
  isplaymusic: true,
  isplayeffect : true,
  UIFunction: {
    switchMusicChange: function (e) {
      console.log('switchMusicChange 发生 change 事件，携带值为', e.detail.value)
      try {
        wx.setStorageSync('music', e.detail.value)
      } catch (error) {
        console.error(error);
      }

      app.getShowingPage().setMusicPlay();
    },
    switchEffectChange: function (e) {
      console.log('switchEffectChange 发生 change 事件，携带值为', e.detail.value)
      try {
        wx.setStorageSync('effect', e.detail.value)
      } catch (error) {
        console.error(error);
      }

      app.getShowingPage().setEffectPlay();
    },
    oncloseSetting: function () {
      app.getShowingPage().setData({
        settingDlg: "",//设置模板名称
      });
    },
  },
  

}
module.exports = setting
