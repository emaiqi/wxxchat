//index.js

var websocket = require( '../../utils/websocket.js' );
// var msgCtrl = require('../../utils/messageCtrl.js');
var app = getApp();

var msgCtrl =app.message;
app.globalData1++;

//获取应用实例
var app = getApp()

var message = '';

var text = '';

var user = {};

//存储消息返回的处理函数


Page({
  
  onShow: function () { 
    //注册函数
    msgCtrl.addResopnseCallBack(1002, this.loginCallBack);
  },

  onHide: function () { 
    // 取消注册函数
    console.log("chat onHide");
    msgCtrl.removeResopnseCallBack(1002);
  },
  onUnload: function () { 
    // 取消注册函数
     console.log("chat function");
    msgCtrl.removeResopnseCallBack(1002);
  },



  data: {
    message: '',
    text: text
  },
  bindChange: function( e ) {
    message = e.detail.value
  },
  //事件处理函数
  add: function( e ) {

    // var msg = msgCtrl.getProtoBuf( "example.proto", "Message" );
    // msg[ "text" ] = "123郑华明ads"


    var msg = {
      name: "郑华明",
      cmd : 1001
    }
    for(var i =0 ;i<20; i++){
      msgCtrl.sendMessage( msg ,1001);
    }


    // var messageObj = {};
    // nickName = user.nickName;
    // messageObj[nickName] = message;
    // websocket.send(JSON.stringify(messageObj));
  },

  onLoad: function () {
    //已经在 app 中启动 网络了
    // msgCtrl.onConnectSocket();

    // var that = this


    // //调用应用实例的方法获取全局数据
    // app.getUserInfo(function(userInfo){
    //   user = userInfo;

    //   websocket.connect(user, function(res) {
    //     text = res.data +"\n" + text;
    //     that.setData({
    //       text:text
    //     });
    //   })
    // })
  },
  loginCallBack: function (response) { 
    // 登录的回调函数
    console.log("loginCallBack  response " + JSON.stringify(response));
  }  

})
