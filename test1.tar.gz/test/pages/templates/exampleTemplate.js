
// var exampleTemplateJS = {

// }

// exampleTemplateJS.showText = "this is example template text"

// exampleTemplateJS.onClickText = function()
// {
//     console.log("onClikc in exampleTemplate text " + this.showText);
// }

// module.exports = exampleTemplateJS

var app = getApp()

var exampleTemplateJS = {
    UIFunction: {
        onClickText : function(event)
        {
            console.log("onClikc in exampleTemplate text " + this.showText);
            this.changeShowText();
        }
     }   
}

exampleTemplateJS.changeShowText = function()
{
    this.showText = "123"
    // 修改UI显示，需要修改doudizhu中data对应的值
    app.getCurrentPage().setData({
        exampleTemplateData:this
    })
}

exampleTemplateJS.showText = "this is example template text"

module.exports = exampleTemplateJS