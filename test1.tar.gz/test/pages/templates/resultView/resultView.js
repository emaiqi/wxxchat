var resultView = {};
var app = getApp();
var fileCtrl = require( "../../../utils/fileCtrl.js" );
var ResData = require( "../../../demo/ResourceData.js" )
var JMain = require("../../../demo/JControls.js").getJMain()

resultView.resultData = {}

resultView.setResultData = function(response,parent){

         var dizhuResult = 0;
        var dizhuWin = false;
        var finData=[];
        var bgState = "";
        var titleState = "";
        
        var myWin = false;
        for(var i=0;i<response.battleResults.length;i++){
            if(app.globalData.userToken == response.battleResults[i].openid){
                myWin = response.battleResults[i].winType;   //我是否胜利
            }
            if(response.battleResults[i].openid == parent.DiZhuOpenId){
                dizhuResult = response.battleResults[i].winType;  //地主是否胜利
            }
        }

        for(var i=0;i<response.battleResults.length;i++){
            var lineState = "";  
            var lineWeiZi = "#FFFFFF";//本人的字体颜色FFFF00 其它人为白色(FFFFFF)

            if(app.globalData.userToken == response.battleResults[i].openid){
                if(myWin == 1){  //我胜利  设置我的数据
                    bgState = fileCtrl.getFilePathByKey(ResData.UI.jiesuan_shengliban.path);
                    titleState = fileCtrl.getFilePathByKey(ResData.UI.jiesuan_shengli.path);
                    lineState = fileCtrl.getFilePathByKey(ResData.UI.jiesuan_shenglitiao2.path)
                }else{  //我失败  设置我的数据
                    bgState = fileCtrl.getFilePathByKey(ResData.UI.jiesuan_shibaiban.path);
                    titleState = fileCtrl.getFilePathByKey(ResData.UI.jiesuan_shibai.path);
                    lineState = fileCtrl.getFilePathByKey(ResData.UI.jiesuan_shibaitiao2.path)
                }
                lineWeiZi = "#FFFF00"
            }else{
                if(myWin == 1){  //我胜利  设置别人的的数据
                    lineState = fileCtrl.getFilePathByKey(ResData.UI.jiesuan_shenglitiao1.path)
                }else{  //我失败  设置别人的的数据
                    lineState = fileCtrl.getFilePathByKey(ResData.UI.jiesuan_shibaitiao1.path)
                }
            }

            var openid = response.battleResults[i].openid;
            var dizhu = (response.battleResults[i].openid == parent.DiZhuOpenId);  //是否是地主
            var kuang = dizhu?fileCtrl.getFilePathByKey(ResData.UI.toukuang1.path):fileCtrl.getFilePathByKey(ResData.UI.toukuang2.path);  
            var mao = dizhu?"display:liner;":"display:none;";
            // var lineState = response.battleResults[i].winType==1?"/images/jiesuan_shibaitaio2.png":"/images/jiesuan_shibaitaio1.png";
            finData[i]={
                isDiZhu : dizhu,
                kuangImg : kuang,
                maoVsb : mao,  
                lineImg:lineState,
                lineWeiZiColor:lineWeiZi,
                toukuang : parent.data.toukuang2,
                avatarUrl : parent.PlayerInfo[openid].avatarUrl,
                nickName : parent.PlayerInfo[openid].nickName,
                bei : response.battleResults[i].multiple,
                rewardScore : response.battleResults[i].rewardScore,
                totleScore : response.battleResults[i].totalScore,
            }
            

        }/*for end*/


        var playerState = "";  //地主或农民的头像
        if(app.globalData.userToken == parent.DiZhuOpenId){
            if(dizhuResult==1){  //地主胜利
                dizhuWin = true;
                playerState = fileCtrl.getFilePathByKey(ResData.UI.dishengli.path);//"/img/dishengli.png"
            }else{  //地主失败
                dizhuWin = false;
                playerState = fileCtrl.getFilePathByKey(ResData.UI.dishibai.path);//"/img/dishibai.png"
            }
        }else{
            if(dizhuResult==0){  //农民胜利
                dizhuWin = false;
                playerState = fileCtrl.getFilePathByKey(ResData.UI.nongshengli.path);//"/img/nongshengli.png"
            }else{  //农民失败
                dizhuWin = true
                playerState = fileCtrl.getFilePathByKey(ResData.UI.nongshibai.path);//"/img/nongshibai.png"
            }
        }

        var MPKS = fileCtrl.getFilePathByKey(ResData.UI.button_l_mingpaikaishix.path);  //名牌开始按钮图片地址
        var MPKSNUM = fileCtrl.getFilePathByKey(ResData.Images.shuzi_1_5.path); //倍数
        var JXYX = fileCtrl.getFilePathByKey(ResData.UI.button_l_jixuyouxi.path);   //继续游戏按钮图片地址
        var CHDI = fileCtrl.getFilePathByKey(ResData.UI.chenghao_di.path);   //称号底条
        var DZMAO = fileCtrl.getFilePathByKey(ResData.UI.icon_dizhu.path);   //地主帽图标
        var GUANG = fileCtrl.getFilePathByKey(ResData.UI.guang.path);   //结算背景光图

        var animation = wx.createAnimation({
            duration:0
        })
        animation.translate(62 * JMain.JZoom.x, 3 * JMain.JZoom.y).step()
        resultView.resultData = {
            isShow:true,
            mingpai:MPKS,
            jixu:JXYX,
            chenghaoDi:CHDI,
            dizhuMao:DZMAO,
            isDizhuWin:dizhuWin,
            jiesuanGuang:GUANG,
            playerStateImg:playerState,
            bgImg:bgState,
            titleImg:titleState,
            data : finData,
            mingpaiNum:MPKSNUM,
            animationData:animation.export()
        };
        app.getCurrentPage().setData({
          resultViewData:this
        })
}

resultView.clearData = function(){
  resultView.resultData = {isShow:false ,data:[]}
  app.getCurrentPage().setData({
    resultViewData:this
  })
}
resultView.UIFunction = {
    onClickRestart: function (event) {
        app.getCurrentPage().resetUI(true);
        app.getCurrentPage().onClickStartGame(event);
    },
}    

module.exports = resultView