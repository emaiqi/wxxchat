
var zhadanView = {}
var app = getApp()


zhadanView.changeShow = function()
{
    this.isShow = true
    // 修改UI显示，需要修改doudizhu中data对应的值
    app.getCurrentPage().setData({
        zhadanView:this
    })
    var timer = setTimeout(zhadanView.Hidden,2000)

    app.getCurrentPage().setData({
        zhadanView:this
    })
}

zhadanView.Hidden = function()
{
    this.isShow = false
}

zhadanView.isShow = false

module.exports = zhadanView