
var util = {};

var scheduleIds = {};


util.formatTime = function formatTime(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()

  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()


  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
}

// var RoomPos2GamePos = { 1: { 2: 3, 3: 2 }, 2: { 1: 2, 3: 3 }, 3: { 1: 3, 2: 2 } }
var GamePos2RoomPos = { 1: { 2: 3, 3: 2 }, 2: { 1: 2, 3: 3 }, 3: { 1: 3, 2: 2 } }

var RoomPos2GamePos = { 1: { 2: 2, 3: 3 }, 2: { 1: 3, 3: 2 }, 3: { 1: 2, 2: 3 } }
/**
 *根据自己网络的位置获取pos玩家的位置，服务器发下的是房间的绝对位置，但是需要转换成游戏中的位置。
 *服务器下发的位置是顺时针，游戏需要的是逆时针（自己的位置 1 ， 右 为2 ，左 为 3））
 */
util.getGamePosByRoomPos = function(selfRoomPOS, playerRoomPos ) { 
  return RoomPos2GamePos[selfRoomPOS][playerRoomPos];
}


/**
 * 计时器，
 * @param interval  触发间隔时间（单位：毫秒），0为每帧都触发，如果interval = 0，推荐使用scheduleUpdate()代替
 * @param repeat    重复次数
 * @param delay     延迟启动时间（单位：毫秒）
 *  */
util.schedule = function (callback, interval = 1000, repeat = 1, delay = 0) {
  if (typeof (callback) != "functoion") {
    console.error("the callback is not a function")
    return;
  }
  var timeOutId;
  var IntervalId;
  var count = repeat;
  var schedule_selector = callback;
  function delayTimeCallback() {
    schedule_selector();
    count--;
    IntervalId = setInterval(intervalCallback, interval);
    scheduleIds[schedule_selector] = IntervalId;
  }
  function intervalCallback() {
    schedule_selector();
    count--;
    if (count <= 0) {
      clearInterval(IntervalId);
      delete scheduleIds[schedule_selector];
    }
  }

  if (delay > 0) {
    timeOutId = setTimeout(delayTimeCallback, delay);
    scheduleIds[schedule_selector] = timeOutId;
  }
  else {
    IntervalId = setInterval(intervalCallback, interval);
    scheduleIds[schedule_selector] = IntervalId;
  }

},
  /**
   * 计时器，
   * @param interval  触发间隔时间（单位：毫秒），0为每帧都触发，如果interval = 0，推荐使用scheduleUpdate()代替
   * @param repeat    重复次数
   * @param delay     延迟启动时间（单位：毫秒）
   *  */
  util.scheduleOnce = function (callback, delay = 1000) {
    if (typeof (callback) != "functoion") {
      console.error("the callback is not a function")
      return;
    }
    var timeOutId;
    var schedule_selector = callback;
    function delayTimeCallback() {
      schedule_selector();
      delete scheduleIds[schedule_selector];
    }
    if (delay > 0) {
      timeOutId = setTimeout(delayTimeCallback, delay);
      scheduleIds[schedule_selector] = timeOutId;
    }
  },
  /**
   *根据 callback 取消计时器， 
   */
util.UnSchedule = function (callback) { 
  if (scheduleIds[schedule_selector]) {
    clearInterval(scheduleIds[schedule_selector]);
    clearTimeout(scheduleIds[schedule_selector]);
    delete scheduleIds[schedule_selector];
  }
}





module.exports = util;
