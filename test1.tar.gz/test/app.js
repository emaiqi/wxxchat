var messageCtrl = require("./utils/messageCtrl.js")
var JMain = require("./demo/JControls.js").getJMain()

App({
  //顶条高度
  topBarHight: 42,
  //初始化网络协议模块
  message: messageCtrl,
  //网络文件地址根目录
  downLoadPath: "http://ddz.blingstorm.com.cn:8080/dou/",
  onLaunch: function () {
    var that = this
    //调用API从本地缓存中获取数据
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    console.log("app onLaunch");
    //设置设备信息
    messageCtrl.onConnectSocket();
    String.prototype.format = function () {
      var args = arguments;
      return this.replace(/\{(\d+)\}/g,
        function (m, i) {
          return args[i];
        });
    }
  },

  getUserInfo: function (cb) {
    var that = this
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },
  //全局数据，微信玩家自己的信息
  globalData: {
    userInfo: null,
    userToken: null,
    hasLogin: false,


    //设计分辨率
    defaultWidth: 320,
    defaultHeight: 526,

    //实际设备分辨率
    windowWidth: 320,  //窗口高度
    windowHeight: 526, //窗口宽度
    pixelRatio: 2,     //设备像素比

    isSingle: false    //是否运行单机， true，单机， false联网

  },
})
