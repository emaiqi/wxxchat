
// var ResourceData = require('ResourceData.js').getResourceData();
// var JControls = require('JControls.js').getJFunction()
var ResourceData = require( 'ResourceData.js' );
var MyClass = require( 'Prototype.js' );
// var JControls = require('JControls.js').getJControls()
var app = getApp();
var fileCtrl = require("../utils/fileCtrl.js")

var t = require( 'JControls.js' );
var JControls = t.getJControls();
var JColor = t.getJColor();

var JFunction = require( 'JControls.js' ).getJFunction()
var JMain = require( 'JControls.js' ).getJMain()

var fontContext = wx.createContext();

// var app = getApp();
// app.DJDDZ={};
function beginDrawCanvas( canvasId, context ) {
    // return;
    //zhm for test
    var context = JMain.JForm.context

    // context.rect( 33, 250, 255, 190 )
    //  var filePath = fileCtrl.getFilePathByKey("img/font/shuzi_3_0.png")
    // context.drawImage("http://ddz.blingstorm.com.cn:8080/dou/img/black_K.png", 20, 20,30,30);    //测试  许彦贺

    //  context.drawImage(filePath, 100, 100, 100,100);    //测试  许彦贺

    // context.drawImage("../Img/logo.png", 100, 100, 100,100);


    // context.stroke()
    // test over
    wx.drawCanvas( {
        canvasId: canvasId,
        actions: context.getActions()
    });
}

function changeTime(){
    wx.drawCanvas( {
        canvasId: "canvasFont",
        actions: fontContext.getActions()
    });
}

function beginDrawTime(num){
    if(GMain.myFont==null){
        GMain.myFont = new GControls.myFont({x:160,y:208},num,3);
    }else{
        GMain.myFont.setTest(num);
    }

    GMain.myFont.fontShow(fontContext);
    changeTime();
}

var DJDDZ = {};
DJDDZ.Init = function( canvasID ) {
    JFunction.registerInit( function() {
        JMain.JForm = new JControls.Form( GMain.Size, canvasID )//  .setBGImage( ResourceData.Images.bg1 );
        JMain.JForm.setDes( "root" );
        JMain.JForm.clearControls();

        GMain.BtnPanel = new JControls.Object( { x: 50 * JMain.JZoom.x, y: 140 * JMain.JZoom.y }, { width: 300, height: 25 });//用于显示游戏控制按钮
        GMain.BtnPanel.setDes( "btnPanerl" );
        GMain.PokerPanel0 = new GControls.PokerPanel( { x: 132 , y: 2 }, { width: 70, height: 40 }, 0, 0 );//用于显示底牌，显示对象存储在GMain.Poker[0]
        GMain.PokerPanel0.setDes( "底牌panel" );

// var myPanelPos = getApp().globalData.windowHeight - 240* JMain.JZoom.y; //360 
// console.log("myPanelPos =",myPanelPos,"windowHeight=",getApp().globalData.windowHeight);
        var myPosY = 330 //;/JMain.JZoom.y;
        GMain.PokerPanel1 = new GControls.PokerPanel( { x: 10 , y: ( myPosY)  }, { width: 300, height: 190 }, 1, 26);// * JMain.JZoom.x );//用于显示自己的牌，显示对象存储在GMain.Poker[1] 高度等于两排牌高度 + 选中牌
        GMain.PokerPanel1.setDes( "自己牌panel" );

        GMain.PokerPanel2 = new GControls.PokerPanel( { x: 175 , y: 43  }, { width: 50, height: 110 }, 2, 13 );//用于显示右边电脑的牌，显示对象存储在GMain.Poker[2]
        // GMain.PokerPanel2.visible = false;
        GMain.PokerPanel2.setDes( "右边牌panel" );

        GMain.PokerPanel3 = new GControls.PokerPanel( { x: 68 , y: 43  }, { width: 100, height: 110 }, 3, 13 );//用于显示左边电脑的牌，显示对象存储在GMain.Poker[3]
        // GMain.PokerPanel3.visible = false;
        GMain.PokerPanel3.setDes( "左边电脑牌panel" );

        GMain.PokerPanel4 = new GControls.PokerPanel( { x: 32 , y: 250 }, { width: 255, height: 60 }, 4, 20  );//用于显示出的最后一手牌，显示对象存储在GMain.Poker[4]
        GMain.PokerPanel4.setDes( "自己的最后一手牌" );

        //右边最后一手牌
        GMain.PokerPanel5 = new GControls.PokerPanel( { x: 200 , y: 157 }, { width: 200, height: 60 }, 5, 18  );
        GMain.PokerPanel5.setDes( "左手的最后一手牌" );
        //左边最后一手牌
        GMain.PokerPanel6 = new GControls.PokerPanel( { x: 15 , y: 158 }, { width: 200, height: 60 }, 6, 18  );
        GMain.PokerPanel6.setDes("右手的最后一手牌");
         //发牌区域
        GMain.PokerPanel7 = new GControls.PokerPanel( { x:90 , y: 125 }, { width: 130, height: 215 }, 7, 18  );
        GMain.PokerPanel7.setDes( "底牌动画Panel" );

        JMain.JForm.addControlInLast( [GMain.PokerPanel7, GMain.PokerPanel0, GMain.PokerPanel1
            , GMain.PokerPanel2, GMain.PokerPanel3, GMain.PokerPanel4,GMain.PokerPanel5,GMain.PokerPanel6, GMain.BtnPanel ] );
        DJDDZ.InitGame();
        // JMain.JForm.show();


        //测试  许彦贺
        // beginDrawCanvas( canvasID, JMain.JForm.context );
        // wx.drawCanvas({
        //     canvasId:canvasID,
        //     actions:JMain.JForm.context.getActions()
        // });
    })

    JFunction.PreLoadData( GMain.URL );
}

DJDDZ.InitGame = function() {
    GMain.Poker = [];
    GMain.myPoker = [];  //自定义牌组件  许彦贺
    for( var i = 0;i < 7;i++ )GMain.Poker[ i ] = [];//初始化扑克对象存储空间
    // for(var j=0;j<54;j++)GMain.Poker[0][j]=new GControls.Poker({x:0,y:0},{width:0,height:0},j+1);//生成扑克对象  测试
    for (var j = 0; j < 54; j++) {
        GMain.myPoker[j] = [];
        // GMain.Poker[0][j]=new GControls.Poker(j+1);//生成扑克对象
        GMain.Poker[0][j] = new GControls.myPoker(j + 1, 1, 1, 0.4, 1, false);
        GMain.Poker[0][j].setDes("poker " + (j + 1));
    }
    GMain.PokerPanel0.hidePoker = true;//hidePoker为true，显示扑克背面
    GMain.PokerPanel1.hidePoker = false;//hidePoker为false，显示扑克正面
    GMain.PokerPanel2.hidePoker = true;
    GMain.PokerPanel3.hidePoker = true;
    GMain.PokerPanel4.hidePoker = false;
    GMain.PokerPanel5.hidePoker = false;
    GMain.PokerPanel6.hidePoker = false;
    GMain.PokerPanel7.hidePoker = true; //增加发牌动画的panel
    GMain.PokerPanel1.toSelectPoker = false;
    // GMain.PokerPanel0.density = 1;//设置扑克牌显示密度
    GMain.PokerPanel7.density = 0;//设置扑克牌显示密度 
    GMain.ToPlay = false;
    GMain.LastHandPokerType = null;
    GMain.DealingNum = 0;
    GMain.DealerNum = 1;//JFunction.Random( 1, 3 );
    GMain.BeginNum = GMain.DealerNum;//初始化发牌起始标识
    /*                                  1、 牌 2、花色       3、position                                       4、牌背景缩放 5、左上角缩放 6、中心图缩放 7、中心图是否需要*/
    // GMain.myPoker = new GControls.myPoker(8,1,{x:ResourceData.Images.bg1.cellSize.width/2,y:ResourceData.Images.bg1.cellSize.height/2},1.2,1,1.2,true);  //生成一个自定义扑克  许彦贺
    /* 1、牌 2、牌背景缩放 3、左上角缩放 4、中心图缩放 5、中心图是否需要*/
    // GMain.myPoker = new GControls.myPoker(1,1,0.4,1,true);
    // JMain.JForm.addControlInLast([GMain.myPoker]);
}

DJDDZ.initData = function( myPokerData, hiddenPokersData ) {
    GMain.Poker[ 0 ] = hiddenPokersData;
    // GMain.Poker[1] = myPokerData;
    GMain.myPokerData = myPokerData;
    DJDDZ.Dealing();
}

//服务器下发发牌结果之后，开始发牌
// list:{1:[],2:[],3:[]} 每个位置玩家的牌id
// handPoker：三张底牌
DJDDZ.DealingList = function( list, handPoker ) {
    GMain.PokerList = list
    GMain.HandPoker = handPoker;
    DJDDZ.onStartDealing();
}

//开始发牌
DJDDZ.onStartDealing = function() {
    GMain.BtnPanel.visible = false;
    // GMain.PokerPanel0.visible = true;
    GMain.PokerPanel7.visible = true;
    DJDDZ.Dealing();
}

DJDDZ.Dealing = function() {//发牌
    GMain.BtnPanel.visible = false;   //测试  许彦贺
    if( GMain.DealingHandle ) clearTimeout( GMain.DealingHandle );
    if (GMain.DealingNum >= 51) {//已发完牌
        GMain.PokerPanel0.visible = true;
        GMain.PokerPanel7.visible = false;
        GMain.MaxScore = 0;
        GMain.GrabTime = 0;
        GMain.PokerPanel0.density = 21;
        //设置一下三张底牌
        if( getApp().globalData.isSingle ) {
            //  单机
            for( var i = 0;i < 3;i++ ) {
                GMain.Poker[ 0 ][ i ] = new GControls.myPoker( i + 30, 1, 1, 0.4, 1, false );
                GMain.Poker[ 0 ][ i ].setBigSe( false );  //设置显示大花
            }
        }
        else {
            GMain.PokerPanel0.clearControls();
            for( var i = 0;i < GMain.HandPoker.length;i++ ) {
                // 联网
                GMain.Poker[ 0 ][ i ] = new GControls.myPoker( GMain.HandPoker[ i ], 1, 1, 0.4, 1, false );
                GMain.Poker[ 0 ][ i ].setBigSe( false );  //设置显示大花
            }
        }
        if( getApp().globalData.isSingle ) {
            //单机逻辑
            DJDDZ.GrabTheLandlord();//抢地主
        }
        else {
            //联网，调用发牌结束，显示叫地主
            //TODO
            // JMain.JForm.show();
            getApp().getShowingPage().onDealingOver()
        }

    } else {
        if( GMain.DealerNum > 3 ) GMain.DealerNum = 1;
        //选择底牌最后一个做角标
        var r = GMain.Poker[ 0 ].length - 1;
        if (getApp().globalData.isSingle) {
            //最后添加一张牌，并重新设置数据
            // var cardId = GMain.PokerList[GMain.DealerNum ].shift();
            GMain.Poker[GMain.DealerNum].splice(GMain.Poker[GMain.DealerNum].length, 0, new GControls.myPoker(GMain.DealingNum + 1, 1, 1, 0.4, 1, false));
            //删除底牌最后一个
            GMain.Poker[0].splice(r, 1);
            DJDDZ.setBigSeVisible();
        }
        else {

            GMain.Poker[0][r].moveEndCallback = (function (DealerNum) {
                return function () {
                    //最后添加一张牌，并重新设置数据
                    var cardId = GMain.PokerList[DealerNum].shift();
                    GMain.Poker[DealerNum].splice(GMain.Poker[DealerNum].length, 0, new GControls.myPoker(cardId, 1, 1, 0.4, 1, false));
                    //删除底牌最后一个
                    // GMain.Poker[0].splice(, 1);
                    GMain.Poker[0].pop();
                    DJDDZ.setBigSeVisible();
                }
            })(GMain.DealerNum);
            GMain.Poker[0][r].moveStep = { x: 0, y:1 };
            GMain.Poker[0][r].moveEnd = { x: 0, y: 320 };
            

            //每30毫秒刷新一下动画 
            if (!GMain.DealingAinHandl) {
                GMain.DealingAinHandle = setInterval(() => {
                    JMain.JForm.addControlInLast([GMain.myFont]);
                    JMain.JForm.show();
                    //测试  许彦贺
                    beginDrawCanvas("canvas1", JMain.JForm.context);

                }, 30);
            }
        }

        GMain.DealingNum++;
        GMain.DealerNum++;
        GMain.DealingHandle = setTimeout(DJDDZ.Dealing, 200);//200毫秒发一张牌
        
    }

    if (!GMain.DealingAinHandl) {
        JMain.JForm.addControlInLast([GMain.myFont]);
        JMain.JForm.show();
        //测试  许彦贺
        beginDrawCanvas("canvas1", JMain.JForm.context);
    }    

}

//服务器通知最终抢地主结果
DJDDZ.onGrabTheLandlord = function( LandlordPos ) {
    GMain.DealerNum = GMain.LandlordNum = LandlordPos;
    GMain.LastHandNum = 0;
    GMain.PokerPanel0.hidePoker = false;
    // GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, GMain.Poker[ 0 ][ 2 ] );
    // GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, GMain.Poker[ 0 ][ 1 ] );
    // GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, GMain.Poker[ 0 ][ 0 ] );
    GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, new GControls.myPoker(  GMain.Poker[ 0 ][ 2 ].key, 1, 1, 0.4, 1, false ) );
    GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, new GControls.myPoker(  GMain.Poker[ 0 ][ 1 ].key, 1, 1, 0.4, 1, false ) );
    GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, new GControls.myPoker(  GMain.Poker[ 0 ][ 0 ].key, 1, 1, 0.4, 1, false ) );
    DJDDZ.setBigSeVisible();
    JMain.JForm.show();
    //测试  许彦贺
    beginDrawCanvas( "canvas1", JMain.JForm.context );
    // DJDDZ.ToPlay();
}

//开始进入出牌
DJDDZ.onStartPlay = function() {
    //可以出牌了，地主出牌
    GMain.ToPlay = true;
    console.log("onStartPlay   " + GMain.LandlordNum);
    this.onPlayingCard( GMain.LandlordNum )
}

//广播玩家出牌
// pokerPos: 出牌的num
// nextPos: 下一个改出牌的num
DJDDZ.onResponsePlayCard = function( pokerPos, nextPos, pokerList ) {
    //显示出的牌
    if(typeof(pokerList) == "undefined" || pokerList.length == 0)
    {
        //不出
    }
    else
    {
        this.onShowPlayCard(pokerPos, pokerList )
        // 记录上一手牌是谁出的
        //只有出牌，才记录上一次出手
        GMain.LastHandNum = pokerPos;
    }
    //记录当前出手的num
    GMain.DealerNum = nextPos;

    //如果上一次出手和当前出手同一个人，表示别的玩家pass
    if( GMain.LastHandNum === GMain.DealerNum ) {
        GMain.LastHandNum = 0
    }
   this.onPlayingCard(GMain.DealerNum);

}

DJDDZ.onPlayingCard = function(pos)
{
    // 页面设置显示,指向下一个出牌用户等
    getApp().getShowingPage().onPlay( pos, GMain.LastHandNum == 2 || GMain.LastHandNum == 3 );
    //该自己出牌
    if( pos === 1 ) {
        this.onPlayCard()
    }
    else {

    }
    this.onStartCountDown();
}

//自己选择牌
DJDDZ.onPlayCard = function() {
    GMain.PokerPanel1.toSelectPoker = true;
}

//点击出牌处理
DJDDZ.onClickPlayCard = function( pokerList ) {
    var _pokerNumbers = [];
    var _pokerIds = [];
    for( var i = GMain.Poker[ GMain.DealerNum ].length - 1;i >= 0;i-- ) {
        if( GMain.Poker[ GMain.DealerNum ][ i ].isSelected ) {
            _pokerNumbers[ _pokerNumbers.length ] = GMain.Poker[ GMain.DealerNum ][ i ].pokerNumber;
            _pokerIds[ _pokerNumbers.length ] = GMain.Poker[ GMain.DealerNum ][ i ].key;
            // GMain.Poker[ 4 ].splice( GMain.Poker[ 4 ].length, 0, GMain.Poker[ GMain.DealerNum ][ i ] );
            // GMain.Poker[ GMain.DealerNum ].splice( i, 1 );
        }
    }

    if( DJDDZ.CheckPlayPoker( _pokerNumbers,true ) ) {
        // GMain.Poker[ 4 ] = [];//清空出牌存储空间
        //通知服务器出牌
        this.sendPokerToServer(_pokerIds)
        GMain.LastHandPokerType = DJDDZ.GetPokerType( _pokerNumbers );//设置最后一手牌牌型
    }
    // else {
    //     // alert("出牌不符合规则，请重新选择！");
    //     getApp().getCurrentPage().setToastHidden()
    // }
}

DJDDZ.drawTimeNum = function(num){
    beginDrawTime(num);
}

DJDDZ.setTimeVisible = function(vsb){
    if(typeof(GMain.myFont) != "undefined" &&  GMain.myFont.visible != vsb)
        GMain.myFont.visible = vsb;

    wx.drawCanvas( {
        canvasId: "canvasFont",
        actions: fontContext.getActions()
    });
}

//服务器下发其他玩家出牌消息
//pokerList 出牌的id列表
DJDDZ.onShowPlayCard = function( pokerNum, pokerList ) {
    GMain.Poker[ pokerNum + 3 ] = [];//清空出牌存储空间
    if(typeof(pokerList) == "undefined" || pokerList.length == 0)
    {
        return;
    }
    var _pokerNumbers = [];
    // var _pokerIds = [];
    for( var i = GMain.Poker[ GMain.DealerNum ].length - 1;i >= 0;i-- ) {
        for( var j = 0;j < pokerList.length;j++ ) {
            if( GMain.Poker[ GMain.DealerNum ][ i ].key == pokerList[ j ] ) {
                _pokerNumbers[ _pokerNumbers.length ] = GMain.Poker[ GMain.DealerNum ][ i ].pokerNumber;
                GMain.Poker[ pokerNum + 3 ].splice( GMain.Poker[ pokerNum + 3 ].length, 0, GMain.Poker[ GMain.DealerNum ][ i ] );
                GMain.Poker[ GMain.DealerNum ].splice( i, 1 );
                pokerList.splice( j, 1 );
                break;
            }
        }
    }
    GMain.LastHandPokerType = DJDDZ.GetPokerType( _pokerNumbers );//设置最后一手牌牌型
    DJDDZ.setBigSeVisible();
    JMain.JForm.show();
    beginDrawCanvas( "canvas1", JMain.JForm.context );
}

DJDDZ.setBigSeVisible = function() {
    if( GMain.Poker[ 1 ].length > 0 ) {  //设置最后一张牌有大花
        for( var i = 0;i < GMain.Poker[ 1 ].length;i++ ) {
            GMain.Poker[ 1 ][ i ].setBigSe( false );
        }
        GMain.Poker[ 1 ][ GMain.Poker[ 1 ].length - 1 ].setBigSe( true );
        if( GMain.Poker[ 1 ].length > 9 ) {
            GMain.Poker[ 1 ][ 9 ].setBigSe( true )
        }
    }
    if( GMain.Poker[ 4 ].length > 0 ) {
        for( var i = 0;i < GMain.Poker[ 4 ].length;i++ ) {
            GMain.Poker[ 4 ][ i ].setBigSe( false );
        }
    }
}

DJDDZ.onClickPass = function() {
    if( getApp().globalData.isSingle )
    {
        for( var i = GMain.Poker[ GMain.DealerNum ].length - 1;i >= 0;i-- )
        GMain.Poker[ GMain.DealerNum ][ i ].isSelected = false;
        GMain.DealerNum++;
        GMain.BtnPanel.visible = false;
        DJDDZ.ToPlay();
    }
    else
    {
       this.sendPokerToServer([])
    }
}

DJDDZ.onClickPlay = function() {
    var _pokerNumbers = [];
    for( var i = GMain.Poker[ GMain.DealerNum ].length - 1;i >= 0;i-- ) {
        if( GMain.Poker[ GMain.DealerNum ][ i ].isSelected ) {
            _pokerNumbers[ _pokerNumbers.length ] = GMain.Poker[ GMain.DealerNum ][ i ].pokerNumber;
        }
    }
    if( DJDDZ.CheckPlayPoker( _pokerNumbers ,true) ) {//判断选中的牌是否符合规则
        DJDDZ.PlayPoker();//出选中的牌
        if( GMain.Poker[ GMain.DealerNum ].length == 0 ) return;//牌出完，游戏结束
        GMain.BtnPanel.visible = false;
        GMain.DealerNum++;
        DJDDZ.ToPlay();//下一位出牌
    }
    // } else {
    //     // alert("出牌不符合规则，请重新选择！");
    //     getApp().getCurrentPage().setToastHidden()
    // }
}
DJDDZ.onClickTips = function() {
    DJDDZ.AISelectPoker();
    JMain.JForm.show();
    //测试  许彦贺
    beginDrawCanvas( "canvas1", JMain.JForm.context );
}

// 开始倒计时
DJDDZ.onStartCountDown = function()
{
    GMain.CountDown = GMain.CountDownTime;
    this.drawTimeNum(GMain.CountDownTime)
    this.setTimeVisible(true)
    if(GMain.CountDownId)
        clearInterval(GMain.CountDownId)
    GMain.CountDownId = setInterval(this.onCoundDownStep, 1000)
}

DJDDZ.onCoundDownStep = function()
{
    GMain.CountDown -= 1;
    // console.log("remaindTime = "+GMain.CountDown)
    DJDDZ.drawTimeNum(GMain.CountDown)
    if(GMain.CountDown <= 0)
    {
        clearInterval(GMain.CountDownId)
        DJDDZ.onTimeOver();
    }
}

// 倒计时结束
DJDDZ.onTimeOver = function()
{
    console.log("Time is Over")
    if(GMain.DealerNum == 1)
    {
        //必须出牌
        if(GMain.LastHandNum == 0)
        {
            for(var i = 0; i <  GMain.Poker[ 1 ].length; i++)
            {
                // 保证所有牌都是未选中
                if( GMain.Poker[ 1 ][i].isSelected)
                {
                    GMain.Poker[ 1 ][i].onClick()
                }
            }
            GMain.Poker[ 1 ][ GMain.Poker[ 1 ].length-1 ].onClick()
            this.onClickPlayCard([GMain.Poker[ 1 ][ GMain.Poker[ 1 ].length-1 ].key])
        }
        else
        {
            DJDDZ.sendPokerToServer([]);
        }
    }
}

/**
 * 将选择的牌发送给服务器
 */
DJDDZ.sendPokerToServer = function(pokerList)
{
    var msg = {
            "cmd": 40017,
            "openId": getApp().globalData.userToken,
            "pokers": pokerList
        }
        app.message.sendMessage( msg );
        getApp().getShowingPage().sendPlayPokerPoker();
}

DJDDZ.onlineGameOver = function()
{
    if(GMain.CountDownId)
        clearInterval(GMain.CountDownId);
    this.setTimeVisible(false)
    this.onOpenPoker([2,3])

}

/**
 * 服务器下发明牌协议
 */
DJDDZ.onResponseOpenPoker = function()
{
    
}
/**
 * 明牌
 * num: 明牌玩家对应的num
 */
DJDDZ.onOpenPoker = function(numList)
{
    for(var i = 0;i < numList.length; i++)
    {
        if(numList[i] == 1) continue;
        GMain["PokerPanel"+numList[i]].hidePoker = false;
    }
    beginDrawCanvas( "canvas1", JMain.JForm.context );
}


DJDDZ.GrabTheLandlord = function() {//抢地主
    if( GMain.GrabTime == 3 && GMain.MaxScore == 0 ) {//没有人抢地主
        DJDDZ.GameOver();
        return;
    }
    if( GMain.MaxScore == 3 || ( GMain.MaxScore > 0 && GMain.GrabTime == 3 ) ) {//地主已产生
        GMain.DealerNum = GMain.LandlordNum;
        GMain.LastHandNum = 0;
        GMain.PokerPanel0.hidePoker = false;
        // GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, GMain.Poker[ 0 ][ 2 ] );
        // GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, GMain.Poker[ 0 ][ 1 ] );
        // GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, GMain.Poker[ 0 ][ 0 ] );

        GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, new GControls.myPoker(  GMain.Poker[ 0 ][ 2 ].key, 1, 1, 0.4, 1, false ) );
        GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, new GControls.myPoker(  GMain.Poker[ 0 ][ 1 ].key, 1, 1, 0.4, 1, false ) );
        GMain.Poker[ GMain.LandlordNum ].splice( GMain.Poker[ GMain.LandlordNum ].length, 0, new GControls.myPoker(  GMain.Poker[ 0 ][ 0 ].key, 1, 1, 0.4, 1, false ) );


        GMain.ToPlay = true;
        DJDDZ.ToPlay();
        return;
    }
    if( GMain.DealerNum > 3 ) GMain.DealerNum = 1;
    if( GMain.DealerNum == 1 ) {//自己抢地主

        // this.onOpenPoker(2)
        // this.onOpenPoker(3)

        GMain.BtnPanel.clearControls();
        var Button1 = new GControls.GrabButton( { x: 5, y: 0 }, { width: 65, height: 25 }, 1 ).setText( "1分" ).setBGImage( ResourceData.Images.btn );
        Button1.setDes( "1分" )
        var Button2 = new GControls.GrabButton( { x: 80, y: 0 }, { width: 65, height: 25 }, 2 ).setText( "2分" ).setBGImage( ResourceData.Images.btn );
        Button2.setDes( "2分" )
        var Button3 = new GControls.GrabButton( { x: 155, y: 0 }, { width: 65, height: 25 }, 3 ).setText( "3分" ).setBGImage( ResourceData.Images.btn );
        Button3.setDes( "3分" )
        var Button4 = new GControls.GrabButton( { x: 230, y: 0 }, { width: 65, height: 25 }).setText( "不抢" ).setBGImage( ResourceData.Images.btn );
        Button4.setDes( "不抢" )
        GMain.BtnPanel.addControlInLast( [ Button1, Button2, Button3, Button4 ] );
        GMain.BtnPanel.visible = true;
        JMain.JForm.show();
        //测试  许彦贺
        beginDrawCanvas( "canvas1", JMain.JForm.context );

    } else {//电脑抢地主
        var r = JFunction.Random( 0, 3 );
        if( r > GMain.MaxScore ) {
            GMain.MaxScore = r;
            GMain.LandlordNum = GMain.DealerNum;
        }
        GMain.DealerNum++;
        GMain.GrabTime++;
        JMain.JForm.show();
        //测试  许彦贺
        beginDrawCanvas( "canvas1", JMain.JForm.context );

        DJDDZ.GrabTheLandlord();
    }
}


DJDDZ.GameOver = function() {
    GMain.BtnPanel.clearControls();
    var Button = new JControls.Button( { x: 235, y: 0 }, { width: 130, height: 50 }).setText( "重新开始" ).setBGImage( ResourceData.Images.btn );
    Button.onClick = function() {
        DJDDZ.InitGame();
        GMain.BtnPanel.visible = false;
        DJDDZ.Dealing();
    }
    GMain.BtnPanel.addControlInLast( [ Button ] );//加载重新开始按钮
    //翻开低牌和左右电脑的牌
    GMain.PokerPanel0.hidePoker = false;
    GMain.PokerPanel2.hidePoker = false;
    GMain.PokerPanel3.hidePoker = false;
    GMain.BtnPanel.visible = true;
    JMain.JForm.show();
    //测试  许彦贺
    beginDrawCanvas( "canvas1", JMain.JForm.context );

}
DJDDZ.ToPlay = function() {//出牌
    DJDDZ.setBigSeVisible();
    JMain.JForm.show();
    //测试  许彦贺
    beginDrawCanvas( "canvas1", JMain.JForm.context );

    if( GMain.DealerNum > 3 ) GMain.DealerNum = 1;
    if( GMain.LastHandNum == GMain.DealerNum ) {
        GMain.LastHandNum = 0;
    }
    getApp().getShowingPage().onPlay( GMain.DealerNum, GMain.LastHandNum == 2 || GMain.LastHandNum == 3 );
    if( GMain.DealerNum == 1 ) {//轮到自己出牌
        GMain.PokerPanel1.toSelectPoker = true;
        JMain.JForm.show();
        //测试  许彦贺
        beginDrawCanvas( "canvas1", JMain.JForm.context );

    } else { //电脑出牌
        if( DJDDZ.AISelectPoker() ) {//电脑AI选牌
            DJDDZ.PlayPoker();//出选中的牌
            if( GMain.Poker[ GMain.DealerNum ].length == 0 ) return;//牌出完，游戏结束
        }
        GMain.DealerNum++;
        setTimeout( DJDDZ.ToPlay, 1500 );//暂停1500毫秒，下一位出牌
    }
}
DJDDZ.CheckPlayPoker = function( _pokerNumbers , showError) {//检查出牌是否符合规则,pokerNumbers从小到大排序
    if(showError == "undefined") showError = false
    var pokerType = DJDDZ.GetPokerType( _pokerNumbers );
    if( pokerType == null ) 
    {
        if(showError)
        {
            console.log("牌型有问题")
            getApp().getShowingPage().showErrorText("出牌不符合规则，请重新选择！")
        }
        return false;//没有获取到牌型
    }
    if( GMain.LastHandNum == 0 )
    {
         return true;//如果是该轮首牌，任何牌型都可以
    }
    else {
        //与该轮出的最后一手牌比较
        if( GMain.PokerTypes[ pokerType.type ].weight > GMain.PokerTypes[ GMain.LastHandPokerType.type ].weight ) 
        {
            return true;//当前牌型可以压前一手牌型
        }
        else if( GMain.PokerTypes[ pokerType.type ].weight == GMain.PokerTypes[ GMain.LastHandPokerType.type ].weight ) 
        {//当前牌型不可以压前一手牌型
            if( pokerType.type == GMain.LastHandPokerType.type && pokerType.length == GMain.LastHandPokerType.length ) 
            {//牌型与出牌数都相同
                if( pokerType.num > GMain.LastHandPokerType.num ) 
                {
                    return true;//数值大的压数值小的
                }
                else
                {
                    if(showError)
                    {
                        getApp().getShowingPage().showErrorText("这个牌型要不起哦~")
                        console.log("数值小于上家 "+GMain.LastHandPokerType.num)
                    }
                    return false;
                } 
            } 
            else
            {
                if(showError)
                {
                    getApp().getShowingPage().showErrorText("牌型不符")
                }
                
                return false;
            } 
        } 
        else 
        {
            if(showError)
            {
                getApp().getShowingPage().showErrorText("这个牌型要不起哦~")
                console.log("数值小于上家 "+GMain.LastHandPokerType.num)
            }
            return false;
        }
    }
}

/**
 * 检查自己的牌是不是能管住对方
 */

DJDDZ.checkHaveBig = function()
{
    //第一手或者上一手是自己的牌 不判断
    if(GMain.LastHandNum == 0) return true
    //王炸，可以GG了
    if(GMain.LastHandPokerType.type == "12" ) return false
  
    var _pokerNumbers = [];
    for( var i = GMain.Poker[ 1 ].length - 1;i >= 0;i-- ) {
        _pokerNumbers[ _pokerNumbers.length ] = GMain.Poker[ 1 ][ i ].pokerNumber;
    }
    var SPN = [];
    if(GMain.LastHandPokerType.num <= GMain.Poker[1].length)
    {
        //如果比你的牌多，只能靠炸弹或者王炸了
        SPN = DJDDZ.GetPokerByType( _pokerNumbers, GMain.LastHandPokerType );
    }
    if( SPN.length == 0 && GMain.LastHandPokerType.type != "1111" ) SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "1111", num: 0, length: 4 });
    if( SPN.length == 0 ) SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "12", num: 0, length: 2 });
    return SPN.length > 0
}

DJDDZ.SplitPoker = function( __pokerNumbers, chaiNum) {//__pokerNumbers已排序，从小到大
    var splitPoker = {};
    for( var type in GMain.PokerTypes ) splitPoker[ type ] = [];
    if( chaiNum == null ) chaiNum = 3;
    if( __pokerNumbers != null && __pokerNumbers.length > 0 ) {
        var _pokerNumbers = [];
        var i, j;
        for( i = 0;i < __pokerNumbers.length;i++ ) _pokerNumbers[ i ] = __pokerNumbers[ i ];//_pokerNumbers从小到大
        if( _pokerNumbers[ _pokerNumbers.length - 1 ] == 18 && _pokerNumbers[ _pokerNumbers.length - 2 ] == 17 ) {
            splitPoker[ "12" ].splice( 0, 0, 17 );
            _pokerNumbers.length = _pokerNumbers.length - 2;
        }
        for( i = chaiNum;i >= 0;i-- ) {
            var str = "1";
            for( var i1 = 1;i1 <= i;i1++ )str = str + String( 1 );
            for( j = _pokerNumbers.length - 1;j >= i;j-- ) {
                if( _pokerNumbers[ j ] == _pokerNumbers[ j - i ] ) {
                    splitPoker[ str ].splice( 0, 0, _pokerNumbers[ j ] );// splitPoker[str]从小到大
                    for( var k = j;k >= j - i;k-- ) {
                        _pokerNumbers.splice( k, 1 );
                    }
                }
            }
        }
    }
    return splitPoker;
}

/**
 * 拆出所有的类型，如三个10，会拆出单10，对10+单10，三个10三种类型
 */
DJDDZ.SplitPokerWithAllType = function( __pokerNumbers, chaiNum) {//__pokerNumbers已排序，从小到大
    var splitPoker = {};
    for( var type in GMain.PokerTypes ) splitPoker[ type ] = [];
    if(allType == "undefined") allType = false
    if( chaiNum == null ) chaiNum = 3;
    if( __pokerNumbers != null && __pokerNumbers.length > 0 ) {
        var _pokerNumbers = [];
        var i, j;
        for( i = 0;i < __pokerNumbers.length;i++ ) _pokerNumbers[ i ] = __pokerNumbers[ i ];//_pokerNumbers从小到大
        if( _pokerNumbers[ _pokerNumbers.length - 1 ] == 18 && _pokerNumbers[ _pokerNumbers.length - 2 ] == 17 ) {
            splitPoker[ "12" ].splice( 0, 0, 17 );
            _pokerNumbers.length = _pokerNumbers.length - 2;
        }
        for( i = chaiNum;i >= 0;i-- ) {
            var str = "1";
            for( var i1 = 1;i1 <= i;i1++ )str = str + String( 1 );
            for( j = _pokerNumbers.length - 1;j >= i;j-- ) {
                //这里保证长度内相同
                if( _pokerNumbers[ j ] == _pokerNumbers[ j - i ] ) {
                    //与之前相同的就不计入，这样可以计算顺子
                    if(splitPoker[ str ].length == 0 || _pokerNumbers[ j ] != splitPoker[ str ][0])
                    {
                        splitPoker[ str ].splice( 0, 0, _pokerNumbers[ j ] );// splitPoker[str]从小到大
                    }
                }
            }
        }
    }
    return splitPoker;
}

DJDDZ.IsStraight = function( numbers ) {//numbers已排序，从小到大
    for( var i = 1;i < numbers.length;i++ ) {
        if( numbers[ i ] - numbers[ i - 1 ] != 1 ) return false;
    }
    return true;
}
DJDDZ.GetPokerType = function( __pokerNumbers, chaiNum ) {//获取__pokerNumbers的牌型，__pokerNumbers已排序，从小到大
    if( chaiNum == null ) chaiNum = 3;
    var splitPoker = DJDDZ.SplitPoker( __pokerNumbers, chaiNum );//把牌拆成非组合类型
    var pokerType = { type: "", num: 0, length: __pokerNumbers.length };
    if( splitPoker[ "12" ].length > 0 ) {
        if( pokerType.length == 2 ) pokerType.type = "12";//王弹
        else pokerType = null;
    } else if( splitPoker[ "1111" ].length > 0 ) {
        if( splitPoker[ "1111" ].length == 1 ) {
            pokerType.num = splitPoker[ "1111" ][ 0 ];
            if( pokerType.length == 4 ) pokerType.type = "1111";//炸弹
            else if( pokerType.length == 6 && ( splitPoker[ "1" ].length == 1 || splitPoker[ "1" ].length == 2 ) ) pokerType.type = "111123";//4带2
            else if( pokerType.length == 8 && splitPoker[ "11" ].length == 2 ) pokerType.type = "11112233";//4带2对
            else pokerType = null;
        } else pokerType = null;
    } else if( splitPoker[ "111" ].length > 0 ) {
        var l = splitPoker[ "111" ].length;
        if( l == 1 || DJDDZ.IsStraight( splitPoker[ "111" ] ) ) {//l=1或GMain.SplitPoker["111"]的值连续
            pokerType.num = splitPoker[ "111" ][ 0 ];
            if( pokerType.length == 3 * l ) pokerType.type = "111";//3条，l>=2时为飞机
            else if( pokerType.length == 4 * l && splitPoker[ "1" ].length == l ) pokerType.type = "1112";//3条带1，l>=2时为飞机
            else if( pokerType.length == 5 * l && splitPoker[ "11" ].length == l ) pokerType.type = "11122";//3条带1对，l>=2时为飞机
            else pokerType = null;
        } else pokerType = null;
    } else if( splitPoker[ "11" ].length > 0 ) {
        var l = splitPoker[ "11" ].length;
        if( l == 1 || ( l >= 3 && DJDDZ.IsStraight( splitPoker[ "11" ] ) ) ) {
            pokerType.num = splitPoker[ "11" ][ 0 ];
            if( pokerType.length == 2 * l ) pokerType.type = "11";//l=1时为对子，l>=3时为连对
            else pokerType = null;
        } else pokerType = null;
    } else if( splitPoker[ "1" ].length > 0 ) {
        var l = splitPoker[ "1" ].length;
        if( l == 1 || ( l >= 5 && DJDDZ.IsStraight( splitPoker[ "1" ] ) ) ) {
            pokerType.num = splitPoker[ "1" ][ 0 ];
            pokerType.type = "1";
        } else pokerType = null;
    } else pokerType = null;
    if( pokerType == null && chaiNum > 0 ) pokerType = DJDDZ.GetPokerType( __pokerNumbers, chaiNum - 1 );
    return pokerType;
}
DJDDZ.GetPokerByType = function( __pokerNumbers, type ) {//从__pokerNumbers中获取type类型的牌
    var _pokerNumbers = [];
    var SPN = [];
    if( __pokerNumbers.length >= type.length ) {
        for( var i = 0;i < __pokerNumbers.length;i++ ) _pokerNumbers[ i ] = __pokerNumbers[ i ];//_pokerNumbers从小到大
        if( type.type == "12" ) {//王炸
            if( _pokerNumbers[ _pokerNumbers.length - 1 ] == 18 && _pokerNumbers[ _pokerNumbers.length - 2 ] == 17 ) {
                SPN.splice( 0, 0, 18 );
                SPN.splice( 0, 0, 17 );
            }
        } else if( type.type == "1" || type.type == "11" || type.type == "111" || type.type == "1111" ) {//非组合类型
            var c = GMain.PokerTypes[ type.type ].allNum - 1;
            for( var j = c;j < _pokerNumbers.length;j++ ) {//从小到大取数值
                while( j < _pokerNumbers.length && _pokerNumbers[ j ] > type.num && _pokerNumbers[ j ] == _pokerNumbers[ j - c ] ) {
                    if( SPN.length > 0 ) {
                        if( _pokerNumbers[ j ] == SPN[ 0 ] ) break;
                        else if( _pokerNumbers[ j ] > SPN[ 0 ] + 1 ) SPN = [];//如果不能连续则清空已选数
                    }
                    for( var k = j;k >= j - c;k-- ) {
                        SPN.splice( 0, 0, _pokerNumbers[ k ] );//选取数值
                        _pokerNumbers.splice( j, 1 );//删除数值
                    }
                    if( SPN.length == type.length ) break;//选取完成
                }
                if( SPN.length == type.length ) break;
            }
        } else if( type.type == "1112" || type.type == "11122" || type.type == "111123" || type.type == "11112233" ) {//组合类型
            var zcy = GMain.PokerTypes[ type.type ].zcy;
            var fcy = GMain.PokerTypes[ type.type ].fcy;
            var fcyNum = GMain.PokerTypes[ type.type ].fcyNum;
            var l = type.length / GMain.PokerTypes[ type.type ].allNum;
            SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: zcy, num: type.num, length: l * GMain.PokerTypes[ zcy ].allNum });//先选主类型
            if( SPN.length > 0 ) {
                for( var i = 0;i < SPN.length;i++ ) {
                    for( var j = 0;j < _pokerNumbers.length;j++ ) {
                        if( SPN[ i ] == _pokerNumbers[ j ] ) {
                            _pokerNumbers.splice( j, 1 );//删除已选数值
                            break;
                        }
                    }
                }
                while( fcyNum > 0 ) {
                    var spn1 = DJDDZ.GetPokerByType( _pokerNumbers, { type: fcy, num: 0, length: GMain.PokerTypes[ fcy ].allNum });
                    for( var i = 0;i < spn1.length;i++ ) SPN[ SPN.length ] = spn1[ i ];
                    fcyNum--;
                }
            }
        }
    }
    if( SPN.length != type.length ) SPN = [];//如果选取不成功，则清空选取数据
    return SPN;
}
DJDDZ.AISelectPoker = function() {//AI选牌
    var _pokerNumbers = [];
    for( var i = GMain.Poker[ GMain.DealerNum ].length - 1;i >= 0;i-- ) {
        _pokerNumbers[ _pokerNumbers.length ] = GMain.Poker[ GMain.DealerNum ][ i ].pokerNumber;
    }
    var SPN = [];
    if( DJDDZ.CheckPlayPoker( _pokerNumbers ) ) {//如果只有一手牌，直接出完
        SPN = _pokerNumbers;
    } else {
        if( GMain.LastHandNum == 0 ) {//本轮第一手牌
            var splitPoker = DJDDZ.SplitPoker( _pokerNumbers );
            if( splitPoker[ "111" ].length > 0 ) {
                //出3条或飞机，优先飞机
                if( splitPoker[ "111" ][ 0 ] < 7 || ( splitPoker[ "1" ].length == 0 && splitPoker[ "11" ].length == 0 ) ) {
                    if( splitPoker[ "11" ].length > 0 && ( splitPoker[ "11" ][ 0 ] < 7 || splitPoker[ "1" ].length == 0 ) ) {
                        for( var i = GMain.PokerTypes[ "11122" ].maxL;i > 0;i-- ) {
                            SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "11122", num: 0, length: 5 * i });
                            if( SPN.length > 0 ) break;
                        }
                    }
                    if( SPN.length == 0 && splitPoker[ "1" ].length > 0 && splitPoker[ "1" ][ 0 ] < 15 ) {
                        for( var i = GMain.PokerTypes[ "1112" ].maxL;i > 0;i-- ) {
                            SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "1112", num: 0, length: 4 * i });
                            if( SPN.length > 0 ) break;
                        }
                    }
                    if( SPN.length == 0 ) {
                        for( var i = GMain.PokerTypes[ "111" ].maxL;i > 0;i-- ) {
                            SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "111", num: 0, length: 3 * i });
                            if( SPN.length > 0 ) break;
                        }
                    }
                }
            }
            if( SPN.length == 0 ) {
                var nn = [];
                for( var x = 1;x <= 3;x++ ) {
                    if( GMain.Poker[ x ].length == 1 || GMain.Poker[ x ].length == 2 ) {
                        if( GMain.DealerNum == GMain.LandlordNum ) {
                            if( GMain.DealerNum != x ) nn[ GMain.Poker[ x ].length ] = true;
                        } else {
                            if( GMain.LandlordNum == x ) nn[ GMain.Poker[ x ].length ] = true;
                        }
                    }
                }
                if( ( splitPoker[ "11" ].length > 0 && splitPoker[ "1" ].length > 0 && ( splitPoker[ "11" ][ 0 ] < splitPoker[ "1" ][ 0 ] || nn[ 1 ] ) )
                    || ( splitPoker[ "11" ].length > 0 && splitPoker[ "1" ].length == 0 ) ) {
                    //出连对
                    for( var i = GMain.PokerTypes[ "11" ].maxL;i > 2;i-- ) {
                        SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "11", num: 0, length: 2 * i });
                        if( SPN.length > 0 ) break;
                    }
                    if( SPN.length == 0 ) SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "11", num: 0, length: 2 });//出对子
                } else {

                    if( splitPoker[ "1" ].length > 0 ) SPN[ SPN.length ] = splitPoker[ "1" ][ 0 ];//出单牌
                }
            }
            if( SPN.length == 0 ) SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "1111", num: 0, length: 4 });//出炸弹
            if( SPN.length == 0 ) SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "12", num: 0, length: 2 });//出王炸
        } else {
            //非第一手牌
            if( GMain.LastHandPokerType.type != "12" ) {
                if( GMain.LandlordNum == GMain.DealerNum || GMain.LastHandNum == GMain.LandlordNum ) {//如果AI是地主或接地主的牌
                    SPN = DJDDZ.GetPokerByType( _pokerNumbers, GMain.LastHandPokerType );
                    if( SPN.length == 0 && GMain.LastHandPokerType.type != "1111" ) SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "1111", num: 0, length: 4 });
                    if( SPN.length == 0 ) SPN = DJDDZ.GetPokerByType( _pokerNumbers, { type: "12", num: 0, length: 2 });
                } else {//接同伴的牌
                    if( GMain.Poker[ GMain.LastHandNum ].length > 5 ) {
                        if( ( GMain.LastHandPokerType.type == "1" && GMain.LastHandPokerType.length == 1 )
                            || ( GMain.LastHandPokerType.type == "11" && GMain.LastHandPokerType.length == 2 ) ) {
                            SPN = DJDDZ.GetPokerByType( _pokerNumbers, GMain.LastHandPokerType );
                            if( SPN.length > 0 && SPN[ 0 ] > 10 ) SPN = [];
                        }
                    }
                }
            }
        }
    }
    if( SPN.length > 0 ) {
        if(GMain.DealerNum == 1)
        {
            //清除所有选择的牌
            for( var j = GMain.Poker[ 1 ].length - 1;j >= 0;j-- ) {
                GMain.Poker[ GMain.DealerNum ][ j ].isSelected = false;
            }
        }
        for( var i = 0;i < SPN.length;i++ ) {
            for( var j = GMain.Poker[ GMain.DealerNum ].length - 1;j >= 0;j-- ) {
                if( !GMain.Poker[ GMain.DealerNum ][ j ].isSelected && GMain.Poker[ GMain.DealerNum ][ j ].pokerNumber == SPN[ i ] ) {
                    GMain.Poker[ GMain.DealerNum ][ j ].isSelected = true;//选牌
                    break;
                }
            }
        }
        return true;
    } else return false
}

DJDDZ.PlayPoker = function() {//出选中的牌
    // GMain.Poker[ 4 ] = [];//清空出牌存储空间
    var _pokerNumbers = [];
    var _pokerKeys = []
    for( var i = GMain.Poker[ GMain.DealerNum ].length - 1;i >= 0;i-- ) {
        if( GMain.Poker[ GMain.DealerNum ][ i ].isSelected ) {
            _pokerNumbers[ _pokerNumbers.length ] = GMain.Poker[ GMain.DealerNum ][ i ].pokerNumber;
            _pokerKeys[_pokerKeys.length] = GMain.Poker[ GMain.DealerNum ][ i ].key
        }
    }
    this.onShowPlayCard(GMain.DealerNum, _pokerKeys);

    GMain.LastHandNum = GMain.DealerNum;//本轮最后一手牌标识
    GMain.LastHandPokerType = DJDDZ.GetPokerType( _pokerNumbers );//设置最后一手牌牌型
    if( GMain.Poker[ GMain.DealerNum ].length == 0 ) DJDDZ.GameOver();//牌出完，游戏结束
}

DJDDZ.nodizhu = function() {  //测试  许彦贺
    GMain.DealerNum++;
    GMain.GrabTime++;
    GMain.BtnPanel.visible = false;
    DJDDZ.GrabTheLandlord();
    return true;
}
DJDDZ.nofapai = function() {  //测试  许彦贺
    for( var i = GMain.Poker[ GMain.DealerNum ].length - 1;i >= 0;i-- )
        GMain.Poker[ GMain.DealerNum ][ i ].isSelected = false;
    GMain.DealerNum++;
    GMain.BtnPanel.visible = false;
    DJDDZ.ToPlay();
}

//叫地主
DJDDZ.onClickApplyLandlord = function( isApply ) {

}

//抢地主
DJDDZ.onClickRobLandlord = function( isRob ) {

}

DJDDZ.setPanelScale = function(num){
    for(var i=0;i<GMain.Poker[ num ].length;i++){
        if( num == 0 || num == 7 ) {
        GMain.Poker[ num ][ i ].setScale( 0.4, 0.8, 0.3, 0.4 );
    } else if( num == 1 ) {
        GMain.Poker[ num ][ i ].setScale( 1, 1, 0.4, 1 );
    } else if( num == 2 ) {
        GMain.Poker[ num ][ i ].setScale( 0.38, 0.5, 0.2, 0.38 );
        GMain.Poker[ num ][ i ].setBigSe(false)
    } else if( num == 3 ) {
        GMain.Poker[ num ][ i ].setScale( 0.38, 0.5, 0.2, 0.38 );
        GMain.Poker[ num ][ i ].setBigSe(false)
    } else if( num == 4 ) {
        GMain.Poker[ num ][ i ].setScale( 0.55, 1, 0.3, 0.55 );
    }
    else if( num == 5 ) {
        GMain.Poker[ num ][ i ].setScale( 0.55, 0.8, 0.3, 0.55 );
    }
    else if( num == 6 ) {
        GMain.Poker[ num ][ i ].setScale( 0.55, 0.8, 0.3, 0.55 );
    }
    }
    
}


var GControls = {};

GControls.myFont = MyClass.create( JControls.Object, {   //自定义   许彦贺
    numCompoment:[]
    ,type:null   
    ,size:null
    ,scale:1                             
    , initialize: function( $super, pos, num, fontType ) {
        $super(pos,{width:0,height:0});
        if(fontType==1){
            this.size = { width: 16.5 * JMain.JZoom.x, height: 19.5 * JMain.JZoom.y }
        }else{
            this.size = { width: 18.5 * JMain.JZoom.x, height: 23 * JMain.JZoom.y }
        }
        this.type = fontType;
        var str = num+"";
        for(var i=0;i<str.length;i++){
            var oneNum = str.substr(i, 1);
            this.numCompoment[i] = new GControls.myFontCompoment(oneNum, this.type, {x:(i*this.size.width-(str.length/2)*this.size.width)*this.scale,y:-this.size.height/2*this.scale},this.scale);
        }

        // this.clearControls();
        // this.addControlInLast( this.numCompoment );
    }
    ,setTest(num){
        this.numCompoment = [];
        var str = num+"";
        for(var i=0;i<str.length;i++){
            var oneNum = str.substr(i, 1);
            this.numCompoment[i]=new GControls.myFontCompoment(oneNum, this.type, {x:(i*this.size.width-(str.length/2)*this.size.width)*this.scale,y:-this.size.height/2*this.scale},this.scale);
        }
    }
    , setFontSizeByScale( scale ) {
        this.scale = scale;
        for(var i=0;i<this.numCompoment.length;i++){
            this.numCompoment[i].setScale(scale);
        }
    }
    , fontBeginShow: function( $super ) {
        $super();


        this.clearFontControls();
        this.addFontControlInLast( this.numCompoment );
    }
    , onClick: function() {
        if( this.parent.toSelectPoker ) {
            this.isSelected = !this.isSelected;
            JMain.JForm.show();
            //测试  许彦贺
            beginDrawCanvas( "canvas1", JMain.JForm.context );

            return true;
        }
        return false;
    }
});

GControls.myFontCompoment = MyClass.create( JControls.Object, {   //自定义一个生成扑克的方法   许彦贺
    type:null
    ,size:null
    ,numKey:null
    ,imgData:null
    ,numPos:null
    /*                              牌num 花色  position  缩放比例 是否显示大花*/
    , initialize: function( $super, num, fontType, pos, scale ) {
        $super();
        if(fontType==1){
            this.size = { width: 16.5 * JMain.JZoom.x, height: 19.5 * JMain.JZoom.y }
        }else{
            this.size = { width: 18.5 * JMain.JZoom.x, height: 23 * JMain.JZoom.y }
        }
        this.numPos = pos;
        this.setSize( {width:this.size.width*scale,height:this.size.height*scale} );
        this.setRelativePosition(this.numPos);
        this.numKey = "shuzi_"+fontType+"_"+num;
        this.imageData = ResourceData.Images[this.numKey];
    }
    ,setTest(num,scale){
        this.setSize( {width:this.size.width*scale,height:this.size.height*scale} );
        this.numKey = "shuzi_"+fontType+"_"+num;
        this.imageData = ResourceData.Images[this.numKey];
    }
    , setScale( scale ) {
        this.setSize( {width:this.size.width*scale,height:this.size.height*scale} );
        this.setRelativePosition({x:this.numPos.x*scale,y:this.numPos.y*scale});
    }
    , fontBeginShow: function( $super ) {
        $super();
        // this.setRelativePosition(this.numPos);
        this.setBGImage(this.imageData);
    }
    , onClick: function() {
        if( this.parent.toSelectPoker ) {
            this.isSelected = !this.isSelected;
            JMain.JForm.show();
            //测试  许彦贺
            beginDrawCanvas( "canvas1", JMain.JForm.context );

            return true;
        }
        return false;
    }
});

GControls.myPoker = MyClass.create(JControls.Object, {   //自定义一个生成扑克的方法   许彦贺
    pokerNumber: null
    , seNumber: null        //花色
    , imageData: null       //图片
    , isHidePoker: true     //隐藏
    , isSelected: null
    , pokerData: null
    , scaleBg: null
    , scaleNum: null
    , scaleHua: null
    , scaleBig: null
    , bigSe: null
    , key: null
    , moveStep: { x: 0, y: 0 }  //发牌动画每帧移动的距离
    , moveEnd: { x: 0, y: 0 }   //发牌动画移动到最终目的
    , moveEndCallback :null     //移动到最终目的后的回调
    /*                              牌num 花色  position  缩放比例 是否显示大花*/
    , initialize: function( $super, imageName, scaleBg, scaleNum, scaleHua, scaleBig, bigSe ) {
        var size = GMain.PokerSize;
        this.scaleBg = scaleBg;
        var mySize = { width: size.width * this.scaleBg, height: size.height * this.scaleBg };
        $super();
        this.setSize( mySize );
        this.key = imageName;
        this.imageData = CardData[ this.key ];
        this.isSelected = false;
        this.scaleNum = scaleNum;
        this.scaleHua = scaleHua;
        this.scaleBig = scaleBig;
        this.bigSe = bigSe;
        this.pokerNumber = this.imageData.num;
        this.seNumber = this.imageData.se;
        this.isSelected = false;

        GMain.myPoker[ this.key - 1 ][ 0 ] = new GControls.myPokerCompoment( this.key, this.imageData.se, GMain.PokerNumSize, this.scaleNum, "num" );
        // if(this.imageData.num!=16&&this.imageData.num!=17)
        GMain.myPoker[ this.key - 1 ][ 1 ] = new GControls.myPokerCompoment( this.key, this.imageData.se, GMain.PokerHuaSize, this.scaleHua, "pic" );
        // if(this.bigSe)
        GMain.myPoker[ this.key - 1 ][ 2 ] = new GControls.myPokerCompoment( this.key, this.imageData.se, GMain.PokerHuaSize, this.scaleBig, "picBig" );

    }
    , setScale( scaleBg, scaleNum, scaleHua, scaleBig ) {
        this.scaleBg = scaleBg;
        var size = GMain.PokerSize;
        var mySize = { width: size.width * this.scaleBg, height: size.height * this.scaleBg };
        this.setSize( mySize );
        this.scaleNum = scaleNum;
        this.scaleHua = scaleHua;
        this.scaleBig = scaleBig;

        GMain.myPoker[ this.key - 1 ][ 0 ].setScale( this.scaleNum );
        // if(this.imageData.num!=16&&this.imageData.num!=17)
        GMain.myPoker[ this.key - 1 ][ 1 ].setScale( this.scaleHua );
        // if(this.bigSe)
        GMain.myPoker[ this.key - 1 ][ 2 ].setScale( this.scaleBig );

    }
    , setBigSe( vsb ) {
        this.bigSe = vsb;
    }
    , beginShow: function( $super ) {
        // $super();
        if( this.parent.hidePoker ) {
            var size = GMain.PokerBgSize;
            var mySize = { width: size.width * 0.61, height: size.height * 0.61 };
            this.setBGImage( ResourceData.Images.cardBg );
        }
        else {
            this.setBGImage( ResourceData.Images.card );
            var tmp = this.scaleNum;
            // GMain.myPoker[this.key-1][0].setRelativePosition({x:0,y:0});

            GMain.myPoker[ this.key - 1 ][ 0 ].setRelativePosition( { x: 10 * tmp, y: 5 * tmp });
            GMain.myPoker[ this.key - 1 ][ 1 ].setRelativePosition( { x: 10 * tmp, y: 25 * tmp });
            GMain.myPoker[ this.key - 1 ][ 2 ].setRelativePosition( { x: 20 * tmp, y: 40 * tmp });


            if( this.imageData.num == 17 || this.imageData.num == 18 ) {
                GMain.myPoker[ this.key - 1 ][ 1 ].visible = false;
            } else {
                GMain.myPoker[ this.key - 1 ][ 1 ].visible = true;
            }

            GMain.myPoker[ this.key - 1 ][ 2 ].visible = this.bigSe;


            this.clearControls();
            this.addControlInLast( GMain.myPoker[ this.key - 1 ] );

        }
        $super();

    }
    , onClick: function() {
        if( this.parent.toSelectPoker ) {
            this.isSelected = !this.isSelected;
            JMain.JForm.show();
            //测试  许彦贺
            beginDrawCanvas( "canvas1", JMain.JForm.context );

            return true;
        }
        return false;
    }
    //移动牌，并且当牌到达指定位置之后，
    , move: function () { 
        if (this.moveStep.x == 0 && this.moveStep.y == 0)
            return;
        this.position.x += this.moveStep.x;
        this.position.y += this.moveStep.y;
        var isEnd = false;
        if (this.position.x > this.moveEnd.x) { this.position.x = this.moveEnd.x; isEnd = true;}
        if (this.position.y > this.moveEnd.y) {this.position.y = this.moveEnd.y; isEnd = true;}
        if (isEnd && this.moveEndCallback) { 
            this.moveEndCallback();
        }
    }
});
GControls.myPokerCompoment = MyClass.create( JControls.Object, {   //自定义一个生成扑克上边组件的方法   许彦贺
    pokerNumber: null
    , seNumber: null
    , imageData: null
    , isHidePoker: true
    , isSelected: null
    , scale: null
    , mysize: null
    , pokerNum: null
    , initialize: function( $super, imageName, se, size, scale, imgType ) {
        var key;
        var size = size;
        this.scale = scale;
        
        var data = CardData[ imageName ];
        this.pokerNum = data.num;
        if(this.pokerNum>15){
            this.pokerNum--;
        }
        if( imgType == "bg" ) {
            size = GMain.PokerSize;
            key = "card";
        } else if( imgType == "num" ) {
            if( this.pokerNum == 16 ) {
                size = GMain.PokerJokerSize;
                key = "black_JOKER";
            } else if( this.pokerNum == 17 ) {
                size = GMain.PokerJokerSize;
                key = "red_JOKER";
            } else {
                size = GMain.PokerNumSize;
                key = ( data.se % 2 == 0 ? "red_" : "black_" ) + ( ( this.pokerNum % 14 ) < 3 ? ( this.pokerNum % 14 + 1 ) : ( this.pokerNum % 14 ) );
            }
        } else if( imgType == "pic" || imgType == "picBig" ) {
            size = GMain.PokerHuaSize;
            if( data.se == 1 ) {
                key = "heitao"
            } else if( data.se == 2 ) {
                key = "hongtao"
            } else if( data.se == 3 ) {
                key = "caohua"
            } else if( data.se == 4 ) {
                key = "fangpian"
            }
            if( this.pokerNum == 16 ) {
                key = "black_dizhu"
            } else if( this.pokerNum == 17 ) {
                key = "red_dizhu"
            }
        }

        this.mysize = size;
        var mySize = { width: size.width * this.scale, height: size.height * this.scale };
        $super();
        this.setSize( mySize );
        this.imageData = ResourceData.Images[ key ];
        this.isSelected = false;
    }
    , setScale( scale ) {
        this.scale = scale;
        var mySize = { width: this.mysize.width * this.scale, height: this.mysize.height * this.scale };
        this.setSize( mySize );
    }
    , beginShow: function( $super ) {
        $super();
        if( this.parent.isHidePoker ) {

        } else {
            if( this.pokerNum == 16 || this.pokerNum == 17 ) {
                var mySize = { width: this.mysize.width * this.parent.scaleBg, height: this.mysize.height * this.parent.scaleBg };
                this.setSize( mySize );
            }
            this.setBGImage( this.imageData );
        }

    }
    , onClick: function() {
        if( this.parent.toSelectPoker ) {
            this.isSelected = !this.isSelected;
            JMain.JForm.show();
            //测试  许彦贺
            beginDrawCanvas( "canvas1", JMain.JForm.context );
            return true;
        }
        return false;
    }
});
GControls.Poker = MyClass.create( JControls.Object, {
    pokerNumber: null
    , seNumber: null
    , imageData: null
    , isHidePoker: true
    , isSelected: null
    , initialize: function( $super, imageName ) {
        $super();
        this.setSize( GMain.PokerSize );
        this.imageData = ResourceData.Images[ imageName ];
        this.pokerNumber = this.imageData.num;
        this.seNumber = this.imageData.se;
        this.isSelected = false;
    }
    , beginShow: function( $super ) {
        $super();
        if( this.isHidePoker ) this.setBGImage( ResourceData.Images.BeiMian );
        else this.setBGImage( this.imageData );
    }
    , onClick: function() {
        if( this.parent.toSelectPoker ) {
            this.isSelected = !this.isSelected;
            JMain.JForm.show();
            //测试  许彦贺
            beginDrawCanvas( "canvas1", JMain.JForm.context );
            return true;
        }
        return false;
    }
});
GControls.GrabButton = MyClass.create( JControls.Button, {
    score: null
    , initialize: function( $super, argP, argWH, score ) {
        $super( argP, argWH );
        this.score = score;
        if( this.score && this.score <= GMain.MaxScore ) this.visible = false;
    }
    , onClick: function() {
        if( this.score ) {
            GMain.MaxScore = this.score;
            GMain.LandlordNum = GMain.DealerNum;
        }
        GMain.DealerNum++;
        GMain.GrabTime++;
        GMain.BtnPanel.visible = false;
        DJDDZ.GrabTheLandlord();
        return true;
    }
});
GControls.PokerPanel = MyClass.create( JControls.Object, {
    pokerPanelNum: null
    , hidePoker: null
    , density: null
    , toSelectPoker: null
    , initialize: function( $super, argP, argWH, num, density ) {
        $super( argP, argWH );
        this.pokerPanelNum = num;
        this.hidePoker = true;
        if( density != null ) this.density = density;
        else this.density = 20;
    }
    , beginShow: function ($super) {
       
        GMain.Poker[ this.pokerPanelNum == 7 ? 0: this.pokerPanelNum].sort( sortNumber );
        var l = GMain.Poker[ this.pokerPanelNum == 7 ? 0: this.pokerPanelNum ].length;
        DJDDZ.setPanelScale(this.pokerPanelNum == 7 ? 0: this.pokerPanelNum);
        if (this.pokerPanelNum == 7 || this.pokerPanelNum == 0) { 
             if(this.visible)
                this.showDealingAnimation();
            $super(); 
            return;
        }
        var row = 0
        for( var i = 0;i < l;i++ ) {
            var x = 0, y = 0
            // if( this.pokerPanelNum == 2 || this.pokerPanelNum == 3 ) {//竖直
            //     var h = GMain.PokerSize.height + ( l - 1 ) * this.density;
            //     y = ( this.size.height - h ) / 2.0 + i * this.density;
            // } else {//水平
                // var w = GMain.PokerSize.width + (l-1) * this.density;
                var startY = 0
                var column = 54;
                var offsetY = 0;
                if(this.pokerPanelNum == 1)
                {
                    // 自己牌
                    column = 10;
                    startY = ( GMain.Poker[ this.pokerPanelNum ][ i ].size.height / 5 );
                    offsetY = GMain.Poker[ this.pokerPanelNum ][ i ].size.height / 3 
                }
                else if(this.pokerPanelNum == 2 || this.pokerPanelNum == 3 || this.pokerPanelNum == 5 || this.pokerPanelNum == 6)
                {
                    //对手牌和对手已出的牌
                    column = 5;
                    offsetY = GMain.Poker[ this.pokerPanelNum ][ i ].size.height / 2 + 2
                }
                else if(this.pokerPanelNum == 4)
                {
                    column = 12;
                    offsetY = GMain.Poker[ this.pokerPanelNum ][ i ].size.height / 2 + 2
                }
                var index =  i % column
                if(i > 0 && i % column == 0) row++
                x = index * this.density;
                if(row == 0 && (this.pokerPanelNum == 4 || this.pokerPanelNum == 1))
                {
                    //自己出的牌，居中
                    var t = l>column ? column : l
                    var scale = this.pokerPanelNum == 4 ? 0.55 : 1
                    var w = GMain.PokerSize.width * scale + (t-1) * this.density;
                    x += (this.size.width/2 - w / 2)// + i * this.density;
                }
                y = startY + row * offsetY
                //选中后的向上抬起的效果
                if( this.toSelectPoker && GMain.Poker[ this.pokerPanelNum ][ i ].isSelected ) y -= ( GMain.Poker[ this.pokerPanelNum ][ i ].size.height / 8 );
            // }
            GMain.Poker[ this.pokerPanelNum ][ i ].setRelativePosition( { x: x, y: y });

            if( this.hidePoker ) GMain.Poker[ this.pokerPanelNum ][ i ].isHidePoker = true;
            else GMain.Poker[ this.pokerPanelNum ][ i ].isHidePoker = false;
        }
        this.clearControls();
        this.addControlInLast( GMain.Poker[ this.pokerPanelNum ] );
        $super();
        function sortNumber( a, b ) {
            if( b.pokerNumber == a.pokerNumber ) return b.seNumber - a.seNumber;
            else return b.pokerNumber - a.pokerNumber;
        }
    },
    showDealingAnimation: function () {
        var row = 0
        var l = GMain.Poker[0].length;    //GMain.Poker[ 0 ]存储所有的牌
        for (var i = 0; i < l; i++) {
            var x = this.pokerPanelNum == 7 ? 60 : 0, y = 0
            var startY = 0
            var column = 54;
            var offsetY = 0;

            x +=  i * this.density;
            y += startY + row * offsetY
            
            GMain.Poker[0][i].setRelativePosition({ x: x, y: y });
            //一直显示牌背 
            GMain.Poker[0][i].isHidePoker = true;
            // if (GMain.Poker[0][i].move)
                // GMain.Poker[0][i].move();
        }
        this.clearControls();
        this.addControlInLast(GMain.Poker[0]);
    }
});

var GMain = {
    Size: { width: 320 * JMain.JZoom.x, height: 526 * JMain.JZoom.y }//屏幕大小
    , URL: app.downLoadPath
    , Poker: null
    , myPoker: null  //自定义扑克  许彦贺
    , myFont:null
    , LandlordNum: null//地主编号
    , BeginNum: null//发牌开始编号
    , DealerNum: null//当前操作编号
    , MaxScore: null//抢牌最高分
    , GrabTime: null//抢牌次数
    , DealingHandle: null//发牌句柄
    , DealingAinHandle: null//发牌动画句柄
    , DealingNum: null//已发牌数
    , myPokerData: null
    , PokerSize: { width: 64 * JMain.JZoom.x, height: 84 * JMain.JZoom.y }//扑克牌大小
    , PokerBgSize: { width: 37 * JMain.JZoom.x, height: 49 * JMain.JZoom.y }//扑克牌大小
    , PokerNumSize: { width: 13 * JMain.JZoom.x, height: 18 * JMain.JZoom.y }//数字大小
    , PokerHuaSize: { width: 35 * JMain.JZoom.x, height: 33 * JMain.JZoom.y }//花色大小
    , PokerJokerSize: { width: 13 * JMain.JZoom.x, height: 75 * JMain.JZoom.y }//王大小
    , PokerWangSize: { width: 38 * JMain.JZoom.x, height: 54 * JMain.JZoom.y }//王图大小
    , LastHandNum: null//标示谁出的最后一手牌
    , LastHandPokerType: null//最后一手牌类型
    , nextHandNum: null    //下一个出手的num
    , ToPlay: null//已抢完地主，出牌中
    , PokerTypes: {//扑克牌类型
        "1": { weight: 1, allNum: 1, minL: 5, maxL: 12 }
        , "11": { weight: 1, allNum: 2, minL: 3, maxL: 10 }
        , "111": { weight: 1, allNum: 3, minL: 1, maxL: 6 }
        , "1111": { weight: 2, allNum: 4, minL: 1, maxL: 1 }
        , "1112": { weight: 1, zcy: "111", fcy: "1", fcyNum: 1, allNum: 4, minL: 1, maxL: 5 }
        , "11122": { weight: 1, zcy: "111", fcy: "11", fcyNum: 1, allNum: 5, minL: 1, maxL: 4 }
        , "111123": { weight: 1, zcy: "1111", fcy: "1", fcyNum: 2, allNum: 6, minL: 1, maxL: 1 }
        , "11112233": { weight: 1, zcy: "1111", fcy: "11", fcyNum: 2, allNum: 8, minL: 1, maxL: 1 }
        , "12": { weight: 3, allNum: 2, minL: 1, maxL: 1 }
    }
    , PokerList: null //服务器下发的发牌结果，发牌结束后清空
    , HandPoker: null //服务器下发的3张底牌
    , CountDownTime: 30 //倒计时时间
    , CountDownId : null    //倒计时的id
    , isPublicPoker: false //是否已经明牌
    , getMingpaiMultiple: function()
    {
        if(this.DealingNum <= 10) return 4;
        if(this.DealerNum <= 14) return 3;
        if(this.DealerNum <= 17) return 2;
        return 1
    }
}

var CardData = {
    1: { se: 3, num: 18 }
    , 2: { se: 4, num: 17 }
    , 3: { se: 4, num: 3 }
    , 4: { se: 4, num: 4 }
    , 5: { se: 4, num: 5 }
    , 6: { se: 4, num: 6 }
    , 7: { se: 4, num: 7 }
    , 8: { se: 4, num: 8 }
    , 9: { se: 4, num: 9 }
    , 10: { se: 4, num: 10 }
    , 11: { se: 4, num: 11 }
    , 12: { se: 4, num: 12 }
    , 13: { se: 4, num: 13 }
    , 14: { se: 4, num: 14 }
    , 15: { se: 4, num: 16 }
    , 16: { se: 3, num: 3 }
    , 17: { se: 3, num: 4 }
    , 18: { se: 3, num: 5 }
    , 19: { se: 3, num: 6 }
    , 20: { se: 3, num: 7 }
    , 21: { se: 3, num: 8 }
    , 22: { se: 3, num: 9 }
    , 23: { se: 3, num: 10 }
    , 24: { se: 3, num: 11 }
    , 25: { se: 3, num: 12 }
    , 26: { se: 3, num: 13 }
    , 27: { se: 3, num: 14 }
    , 28: { se: 3, num: 16 }
    , 29: { se: 2, num: 3 }
    , 30: { se: 2, num: 4 }
    , 31: { se: 2, num: 5 }
    , 32: { se: 2, num: 6 }
    , 33: { se: 2, num: 7 }
    , 34: { se: 2, num: 8 }
    , 35: { se: 2, num: 9 }
    , 36: { se: 2, num: 10 }
    , 37: { se: 2, num: 11 }
    , 38: { se: 2, num: 12 }
    , 39: { se: 2, num: 13 }
    , 40: { se: 2, num: 14 }
    , 41: { se: 2, num: 16 }
    , 42: { se: 1, num: 3 }
    , 43: { se: 1, num: 4 }
    , 44: { se: 1, num: 5 }
    , 45: { se: 1, num: 6 }
    , 46: { se: 1, num: 7 }
    , 47: { se: 1, num: 8 }
    , 48: { se: 1, num: 9 }
    , 49: { se: 1, num: 10 }
    , 50: { se: 1, num: 11 }
    , 51: { se: 1, num: 12 }
    , 52: { se: 1, num: 13 }
    , 53: { se: 1, num: 14 }
    , 54: { se: 1, num: 16 }
}

module.exports = {
    DJDDZ:DJDDZ,
    GMain:GMain
}
