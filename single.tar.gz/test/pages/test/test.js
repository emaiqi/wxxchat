
var context = wx.createContext();
var flag = 0;
var maxCardsNum = 54;  //最大卡牌数
var arrCards=new Array();
var arrLastCards = new Array();
var arrLeftCards=new Array();
var arrRightCards=new Array();
var arrMyCards=new Array();
var arrSrc = new Array();
function intermingle(count){   //打乱牌
    var cur = parseInt(Math.random()*count); 
    var curnum = arrCards[cur]
    var next = parseInt(Math.random()*count);
    var nextnum = arrCards[next]
    for(var i=0;i<500;i++){
        if(next==cur || curnum==nextnum){
            next = parseInt(Math.random()*count);
            nextnum = arrCards[next]
            continue
        }else{
            var tmp = curnum
            curnum = arrCards[next]
            arrCards[next] = tmp 

            next = parseInt(Math.random()*count);
            nextnum = arrCards[next]
        }   
    }
    arrCards[cur] = curnum
} ;

function initGame(){
    Shuffle()
    Licensing()
}
function Shuffle(){  //Shuffle  洗牌
    arrCards.length = 0
    arrLastCards.length = 0
    arrLeftCards.length = 0
    arrRightCards.length = 0
    arrMyCards.length = 0
    for(var i=0;i<maxCardsNum;i++){  //放入牌
        arrCards.push(i+1)
    }
    intermingle(maxCardsNum)
}

function Licensing(){  //Licensing  发牌
    for(var i=0;i<maxCardsNum-3;i++){
        
        switch(i%3){
            case 0:{
                arrLeftCards.push(arrCards[i])
            }break;
            case 1:{
                arrRightCards.push(arrCards[i])
            }break;
            case 2:{
                arrMyCards.push(arrCards[i])
            }break;
        }
    }
    for(var i=maxCardsNum-3;i<maxCardsNum;i++){
        arrLastCards.push(arrCards[i])
    }
    
    sortMyCards()
} 
function sortMyCards(){
    // arrCards.length = 0
    sortCards(arrLastCards)
    sortCards(arrLeftCards)
    sortCards(arrRightCards)
    sortCards(arrMyCards)
}
function sortCards(arr){
    arr.sort(function(a,b){  //a-b:从小到大  b-a:从大到小
        return a-b;
    })
}
function changeSrc(arr){
        arrSrc.length = 0
        arrSrc = new Array();
        for(var i=0;i<arr.length;i++){
        	var str = "http://e.blingstorm.com.cn:8300/ppm/static/admin/dou/"+"img/"+arr[i]+".jpg"
            arrSrc.push(str)
        }
        return arrSrc
}

Page({
    data:{
         windowW:0,
         windowH:0,
         arrLastCardsData:new Array(),
         arrLeftCardsData:new Array(),
         arrRightCardsData:new Array(),
         arrMyCardsData:new Array()
    },

    onLoad: function () {
        var that = this
        wx.getSystemInfo({
            success: function(res) {
                that.setData({
                    windowW:res.windowWidth,
                    windowH:res.windowHeight
                })   
            }
            })
        initGame()

        that.setData({
            arrLastCardsData:changeSrc(arrLastCards),
            arrLeftCardsData:changeSrc(arrLeftCards),
            arrRightCardsData:changeSrc(arrRightCards),
            arrMyCardsData:changeSrc(arrMyCards)
        })
    },

    drawImg:function(){
        console.log('click drawImg')
        context.scale(0.7,0.7)
        for(var i=0;i<arrMyCards.length;i++){
        //     var img = new Image()
        //     var path = "img/"+(i+1)+".jpg"
        //     img.src = "http://e.blingstorm.com.cn:8300/ppm/static/admin/dou/"+path
        //     img.onload = function () {
        //         context.drawImage(this.src, flag++*20+20, 0)
        //         // wx.drawCanvas({
        //         //     canvasId:"canvas1",
        //         //     actions:context.getActions()
        //         // });
        //     }
        //     img.onerror = function () {
        //         console.log("资源加载失败！")
        //     } 
        // }
        
            var path = "img/"+arrMyCards[i]+".jpg"
            var src = "http://e.blingstorm.com.cn:8300/ppm/static/admin/dou/"+path
            context.drawImage(src, i*20+20, 0)
        }
       
        
    },

    start:function(){
        console.log('click start');
         wx.drawCanvas({
          canvasId:"canvas1",
           actions:context.getActions()
        });
    },

    ckickImg:function(img){
        img.detail.x = img.detail.x+100
        console.log("clicImg")
    }
    
})