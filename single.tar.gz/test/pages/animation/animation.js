// animation.js
var util = require('../../utils/util.js')
var ainmations = require("../../utils/Animations.js")
var imageAin = [];

Page({
  data:{
    imagePath:[]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    this.setData({
        'imagePath[0]': "/Img/wechat.png" ,
        'imagePath[1]': "/Img/wechat.png" ,
    })
  },

  runAinmation1 :function ()
  {
    console.log("runAinmation1");
    return
    var that =this ;
    //第一种 动画方法
    if(imageAin[0])
        imageAin[0].stop();
    imageAin[0] = ainmations.createAnimations("/Img/icon_hero1_{0}.png" , 3, 900 , 10 , function (path){
        console.log("当前时间 ：" + util.formatTime(new Date(Date.now() ) ) );
        console.log( "文件路径是" + path);
        that.setData(
            {
            'imagePath[0]' : path
            }
        )

        }, () => console.log("动画完成后的回调"));
    imageAin[0].start(); 
  },

  runAinmation2 : function ()
  {
    console.log("runAinmation2");
    var that =this ;
    if(imageAin[1])
        imageAin[1].stop();
    imageAin[1] = ainmations.createAnimationWtihArray(["/Img/icon_API.png","/Img/icon_API_HL.png","/Img/icon_component.png","/Img/icon_component_HL.png","/Img/wechat.png","/Img/wechatHL.png"],1000,10,function (path){
        console.log("当前时间 ：" + util.formatTime(new Date(Date.now() ) ) );
        console.log( "文件路径是" + path);
        that.setData(
            {
            'imagePath[1]' : path
            }
        )

        }, () => console.log("动画完成后的回调"));
    imageAin[1].start();
  }





})