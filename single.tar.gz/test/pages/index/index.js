//index.js
//获取应用实例
var app = getApp();
//
// var app.message = app.message;
var fileCtrl = require("../../utils/fileCtrl.js")

var intervalID = null

Page({
  data: {
    motto: '登录中...',
    userInfo: {}
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  bindViewTapMyTest: function () {
    wx.navigateTo({
      url: '../test/test'
    })
  },

  onLoad: function () {
    if(getApp().globalData.isSingle)
    {
      //跳过登录协议，直接开始下载图片信息
      fileCtrl.loadAllImg(this.loadImageCallBack);
      return;
    }
       
    if (!app.message.isOpen) {
      intervalID = setInterval(this.WXLogin, 500);
      console.log("服务器没有打开");
    }
    else { 
      this.WXLogin();
    }
    
  },
  /**
   *当连接到服务器之后，才可以发送消息
   */
  WXLogin: function () { 
    if (!app.message.isOpen) {
      return;
    }
    if (intervalID) {
      clearInterval(intervalID);
    }  
    intervalID = null;
    wx.login({
      success: function (res) {
        app.globalData.hasLogin = true;
        console.log("登录成功，获取Code " + res.code);
        let message = { "cmd": 20001, "code": res.code };
        app.message.sendMessage(message);
      },
      false: function () {
        console.log("登录失败");
      }
    })
  },
  
  /**
   *展示的时候 调用（在此处注册登录函数）
   */
  onShow : function () { 
    //注册函数
    app.message.addResopnseCallBack(20002, this.loginCallBack);
    app.message.addResopnseCallBack(20004, this.sendUserInfoCallaBack);
  },
  onUnload: function () { 
    //注册函数
    app.message.removeResopnseCallBack(20002, this.loginCallBack);
    app.message.removeResopnseCallBack(20004, this.sendUserInfoCallaBack);
  },
  /**
   *登录消息的回调，response 为回调的 json 
   */
  loginCallBack: function (response) { 
    //登录成功，状态码 为 0 
    if (response.state == 0) {
      this.setData({ motto: "获取玩家信息..." });
      app.globalData.userToken = response.openid;
      var that = this;
      wx.getUserInfo({
        success: function (res) { 
          app.globalData.userInfo = res.userInfo;
          //向服务器发送玩家信息
          let message = {
            "cmd" :20003,
            "rawData" : res.rawData,
            "signature" : res.signature,
            "encryptData" : res.encryptData
          }
          app.message.sendMessage(message);
          //开始下载图片信息
          // fileCtrl.loadAllImg(that.loadImageCallBack);

        },
        fail: function () { 
          this.setData({motto : "获取玩家失败，wx.getUserInfo.fail" });
        }

      })
    }
    else
    { 
      this.setData({motto : "登录失败，state " + response.state +" , res = " + response.errorReason });
    }

  },

  sendUserInfoCallaBack : function (resopnse) { 
    if (resopnse.state == 0) {
      this.setData({ 
        motto:"加载资源..." 
      })
      if (app.globalData.userInfo)
        app.globalData.userInfo.score = resopnse.score;
      //开始下载图片信息
        fileCtrl.loadAllImg(this.loadImageCallBack);
    }
    else { 
      this.setData({motto : "发送玩家信息失败，state " + response.state +" , res = " + response.errorReason });
    }
  },
  loadImageCallBack: function (cur, total) { 
    console.log("cur = " + cur  + " , total " + total);
    if (cur == 0) {
      this.setData({
        motto: "加载资源 100%,即将进入游戏"
      })
      // 0.1秒后进图游戏界面
      console.log("enter game 0.1s later");
      intervalID =  setInterval(this.enterGame, 100);
      console.log("setInterval after");
    }
    else { 
      this.setData({
        motto : "加载资源 "+parseInt((total-cur) / total *100) +"%"
      })
    }
  },
  enterGame: function () {
    console.log("begin enterGame");
    wx.redirectTo({
      url: "../doudizhu/doudizhu",
      success: function () { 
        console.log("success");
      },
      fail: function () { 
        console.log("fail");
      }
    })
    if(intervalID)
      clearInterval(intervalID);
  }
  
})
