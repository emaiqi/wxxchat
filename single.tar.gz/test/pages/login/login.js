// const AV = require( '../../utils/leancloud.js' );
// AV.init( {
//     appId: "GEkVRhKfRqKLuM3aGyYI8dhP-gzGzoHsz",
//     appKey: "vNUdRqi1y96IavDkoX2weFEy",
// });

var app = getApp()

Page( {
    data: {
        toastHidden: true,
        imgPath:"",
        logData:""
    },

    imgData: {
        img1: "http://h.hiphotos.baidu.com/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=8c22483043a98226accc2375ebebd264/faf2b2119313b07ead669a4d0cd7912396dd8c98.jpg",
        img2: "http://h.hiphotos.baidu.com/zhidao/pic/item/6d81800a19d8bc3ed69473cb848ba61ea8d34516.jpg",
        img3: "http://t1.niutuku.com/960/10/10-202370.jpg",
        img4: "http://www.33lc.com/article/UploadPic/2012-8/201282413335761587.jpg",
        img5: app.downLoadPath
    },

    onLoad: function( options ) {
        var that = this
        console.log( 'Login Page Loaded' );
        console.log( app.globalData.userToken );
        wx.getStorage({
            key:"loadImgOver",
            fail: function(){
                that.loadAllImg()
            }
        })
        
    },
    onReady: function() {
        // 页面渲染完成
    },
    onShow: function() {
        // 页面显示
    },
    onHide: function() {
        // 页面隐藏
    },
    onUnload: function() {
        // 页面关闭
    },
    formSubmit: function( e ) {
        //console.log('form发生了submit事件，携带数据为：', e.detail.value);
        AV.User.logIn( e.detail.value.username, e.detail.value.password ).then( user => {
            // this.globalData.user = user;
            console.log( user );
            app.globalData.userToken = user.id;
            wx.redirectTo( {
                url: "../index/index"
            })
        }, console.error );
    },
    DirectSignUp: function() {
        wx.redirectTo( {
            url: "../signup/signup",
        })
    },
    
    loadAllImg: function() {
        wx.setStorage({
            key:"loadImgOver",
            data:"1"
        })
        this.loadImg();
    },

    loadImg: function(){
        var that = this
        var key;

        // var keys = this.imgData.keys();

        for( var p in this.imgData ) {
            key = p
            wx.downloadFile(
                {
                    url: that.imgData[ p ],
                    type: 'image',
                    success: function( res ) {
                        that.showLog( "file path = " + res.tempFilePath + " p = " + p )

                        wx.saveFile( {
                            tempFilePath: res.tempFilePath,
                            success: function( res ) {
                                var savedFilePath = res.savedFilePath
                                wx.setStorage( {
                                    key: p,
                                    data: savedFilePath,
                                })
                            }
                        })
                    },
                    complete: function() {
                        console.log( "complete " + p );
                        delete that.imgData[ p ]
                        that.loadImg()
                    }
                }
            )
            break;
        }
    },

    TestDrawImage: function( e ) {
        var that = this
        var key = e.detail.value.imgKey;
        
        wx.getStorage( {
            key: key,
            success: function( res ) {
                that.showLog( "getStorage success " + res.data + "   " + key );
                that.showImg( res.data );
            },
            fail: function() {
                that.showLog( "getStorage fail " + key );
                that.showLog( "begin download img , path = " + that.imgData[ key ] );
                if( typeof ( that.imgData[ key ] ) == "string" ) {
                    wx.downloadFile(
                        {
                            url: that.imgData[ key ],
                            type: 'image',
                            success: function( res ) {
                                that.showLog( "file path = " + res.tempFilePath + "  " + key )

                                wx.saveFile( {
                                    tempFilePath: res.tempFilePath,
                                    success: function( res ) {
                                        var savedFilePath = res.savedFilePath
                                        that.showImg( savedFilePath );
                                        wx.setStorage( {
                                            key: key,
                                            data: savedFilePath,
                                        })
                                    }
                                })
                            },
                            fail: function() {
                                that.showLog( "Download " + key + " error" );
                            }
                        }
                    )
                }
                else
                {
                    that.showLog( "key is not a string  , key = "+key );
                }
            }
        })
    },

    showImg: function( path ) {
        // this.setData({
        //    imgPath:path
        //  });

    
        var context = wx.createContext();
        context.drawImage( path, 0, 0, 350, 300 )
        wx.drawCanvas( {
            canvasId: 1,
            actions: context.getActions()
        });
    },

    showLog: function(msg){
        var str = this.data.logData + '\n' + msg
         this.setData({
           logData:str
         });
    },

    Directchat: function() {
        wx.navigateTo( {
            url: "../chat/chat"
        })
    },


    animaitiontest: function() {
        wx.navigateTo( {
            url: "../animation/animation"
        })
    }
})