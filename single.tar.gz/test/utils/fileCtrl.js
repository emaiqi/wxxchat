var resData = require( "../demo/ResourceData.js" )

var app = getApp();
var loadMax;

var fileCtrl = {};
var loadKey = "resourceLoad1";

//等待下载的文件列表
fileCtrl.imgData = new Array();

//下载完成后，保存在本地的key,Path
fileCtrl.saveImgData = {};

fileCtrl.animateData = {
    ani1: ["http://h.hiphotos.baidu.com/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=8c22483043a98226accc2375ebebd264/faf2b2119313b07ead669a4d0cd7912396dd8c98.jpg",
        "http://h.hiphotos.baidu.com/zhidao/pic/item/6d81800a19d8bc3ed69473cb848ba61ea8d34516.jpg",
        "http://t1.niutuku.com/960/10/10-202370.jpg"],
    ani2: ["http://upload.qqbody.com/ns/20160916/033618350he0m5y5n1zj.jpg",
        "http://www.qq1234.org/uploads/allimg/160920/16432040G-4.jpg",
        "http://www.itouxiang.net/uploads/allimg/140318/1_140318092205_1.jpg",
        "http://v1.qzone.cc/avatar/201401/29/22/34/52e91173de0b4073.jpg%21200x200.jpg"],
    ani3: ["http://tx.haiqq.com/uploads/allimg/150321/110H0MU-4.jpg",
        "http://v1.qzone.cc/avatar/201308/18/12/19/52104b392e07d193.jpg%21200x200.jpg",
        "http://v1.qzone.cc/avatar/201303/19/19/22/51484a70d2c5c596.jpg%21200x200.jpg",
        "http://tupian.qqjay.com/tou2/2016/0726/6e06b7264281c2fdae8fa73dd9e91a98.jpg"]
},

    //下载所有数据存储于ResourceData中的文件
    fileCtrl.loadAllImg = function (callback) {
        fileCtrl.callback = callback;
        this.copyResData();
        var that = this;

        //为了保证图片完整
        // fileCtrl.loadImg()
        // return

        wx.getStorage({
            key: loadKey,
            success: function () {
                that.loadSaveData();
            },
            fail: function () {
                fileCtrl.loadImg()
            }
        })
    },

    //通过ResourceData获取需要下载的文件
    fileCtrl.copyResData = function () {
        for (var p in resData.Images) {
            // fileCtrl.imgData[p] = resData.Images[p];
            var data = resData.Images[p];
            fileCtrl.imgData.push(data.path);
        }
        for (var p in resData.UI) {
            // fileCtrl.imgData[p] = resData.Images[p];
            var data = resData.UI[p];
            fileCtrl.imgData.push(data.path);
        }

        loadMax = fileCtrl.imgData.length;
        
    },

    /**
     *如果记录已经下载过文件，这里直接通过key将localPath读入缓存
    */
    fileCtrl.loadSaveData = function () {
        var that = this;
        for (var i = 0; i < this.imgData.length; i++) {
            // var key = that.imgData[ p ].path
            console.log("load img key " + this.imgData[i]);
            this.saveImgData[this.imgData[i]] = wx.getStorageSync(this.imgData[i]);
            //加载图片的 回调
            if ( (parseInt(i%10) ==0 ||loadMax ==  i+1)&& fileCtrl.callback)
                fileCtrl.callback(parseInt(loadMax - i-1), loadMax);
        }
    },
    /**
     *异步下载图片，并且存储在本地
     */
    fileCtrl.loadImg = function () {
        //加载图片的 回调
        if (fileCtrl.callback) {
            console.log(" dangqian  =" + this.imgData.length + " max =" + loadMax);
            fileCtrl.callback(this.imgData.length, loadMax);
        }
        if (this.imgData.length == 0) {
            wx.setStorage({
                key: loadKey
            })
            return;
        }
        var that = this
        var key = this.imgData.pop();
        var path = getApp().downLoadPath + key;

        wx.downloadFile(
            {
                url: path,
                type: 'image',
                success: function (res) {
                    console.log("file path = " + res.tempFilePath + " key = " + key)
                    wx.saveFile({
                        tempFilePath: res.tempFilePath,
                        success: function (res) {
                            var savedFilePath = res.savedFilePath
                            wx.setStorage({
                                key: key,
                                data: savedFilePath,
                                success: function () {
                                    that.saveImgData[key] = savedFilePath;
                                    that.loadImg()
                                }
                            })
                        }
                    })
                },
                fail:function()
                {
                    console.log("load " + key+ " error" );
                },
                complete: function () {
                    console.log("complete " + key);
                }
            }
        )
    },

    // 通过key查找对应的文件在本地的地址,key为ResourceData中的path
    fileCtrl.getFilePathByKey = function( key ) {
        // var value = wx.getStorageSync(key);
        // return value;
        return this.saveImgData[ key ];
    },

    // 通过动画key，查找一组动画需要的图片在本地存储的地址
    //TODO
    // fileCtrl.getAnimatePathArr = function( key ) {
    //     wx.getStorage( {
    //         key: key,
    //         success: function( res ) {
    //             return res.data;
    //         },
    //         fail: function() {
    //             return "";
    //         }
    //     })
    // },

    //TODO
    // fileCfil.downloadImg = function( key, url, fun )
    // {
    //     wx.downloadFile(
    //         {
    //             url: url,
    //             type: 'image',
    //             success: function( res ) {
    //                 console.log( "file path = " + res.tempFilePath + " key = " + key )
    //                 if( typeof ( key ) != "undefined" ) {
    //                     wx.saveFile( {
    //                         tempFilePath: res.tempFilePath,
    //                         success: function( res ) {
    //                             var savedFilePath = res.savedFilePath
    //                             wx.setStorage( {
    //                                 key: key,
    //                                 data: savedFilePath,
    //                             })
    //                         }
    //                     })
    //                 }
    //             },
    //             complete: function() {
    //                 // if
    //             }
    //         }
    //     )
    // }

    module.exports = fileCtrl;
    // module.exports = {
    //     loadAllImg: fileCtrl.loadAllImg,
    //     getFilePathByKey: fileCtrl.getFilePathByKey
    // }