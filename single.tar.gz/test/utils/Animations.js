var Animations = {
    /*
        name  图片的名称 需要和curNum 一起组合成图片的名称 eg：/images/icon_hero1_{0}.png 和 1 可以组合成 /images/icon_hero1_1.png
        num 数目, (图片的ID 从1 开始)
        duration 持续时间，即一次循环所需要的时间
        loop 循环次数，默认为1 
        callback 返回每次修改后的图片的名称
        overCallback 动画结束后的回调
    */
    createAnimations : function (name , num , duration, loop =1 , callback , overCallback)
    {
        var animation = {}; // 动画类
        var name = name ;
        var startNum = 1;
        var id =undefined;
        var loopNum = loop;
        var end = num;
        var that =this;
        //需要手动调用开始方法
        animation.start = function ()
        {
            //如果已经运行，先停止
           animation.stop();
           //第一次需要调用 
            if(callback && typeof callback == "function"){
                callback(name.format(startNum));
                startNum++;
            }
            var interval = duration / end ;
            if(interval < 0 )
                interval =1000;
            id = setInterval( Interval,  interval );
        };
        //计时器，每隔一段时间调用
        function Interval()
        {
            if(callback && typeof callback == "function")
                callback(name.format(startNum));
                
            if(startNum >= end){
                loopNum -- ;
                if(loopNum <= 0){
                    animation.stop();
                    if(overCallback && typeof (overCallback )  == "function")
                        overCallback();
                }
                else{
                    startNum = 0;   //startNum 是从1 开始的， 下面的代码执行+1 操作
                }
            }
            startNum++;
        }
        //手动调用结束 （注意，此时不会执行回调）
        animation.stop = function()
        {
            console.log(" animation.stop");
            if(id)
                clearInterval(id);
            id = undefined ;
        }

    return animation;

    },

    //传入一个图片数组，就可以播放
    /*
        array 图集数组，图片的相对于js的相对路径
        duration 一次循环的时间间隔（毫秒）
        loop 循环次数
        callback 每次改变图片路径的回调
        oeverCallback 动画完成后的回调
    */
    createAnimationWtihArray : function(array , duration,loop =1 , callback , overCallback)
    {
        var animation = {};
        animation.name = array ;
        var startNum = 0;   //从 0 开始（数组从 0 开始）
        var id =undefined;
        var loopNum = loop;
        var end = array.length;
        var that =this;

        animation.start = function()
        {
            //如果已经运行，先停止
           animation.stop();
           //第一次需要调用 
            if(callback && typeof callback == "function"){
                callback(animation.name[startNum]);
                startNum++;
            }
            var interval = duration / end ;
            if(interval < 0 )
                interval =1000;
            id = setInterval( Interval,  interval );
        }
         //计时器，每隔一段时间调用
        function Interval()
        {
            if(callback && typeof callback == "function")
                callback(animation.name[startNum]);
                
            if(startNum +1>= end){
                loopNum -- ;
                if(loopNum <= 0){
                    animation.stop();
                    if(overCallback && typeof (overCallback )  == "function")
                        overCallback();
                }
                else{
                    startNum = -1;   //startNum 是从1 开始的， 下面的代码执行+1 操作
                }
            }
            startNum++;
        }
        //手动调用结束 （注意，此时不会执行回调）
        animation.stop = function()
        {
            console.log(" animation.stop");
            if(id)
                clearInterval(id);
            id = undefined ;
        }

    return animation;

    }

};

module.exports = Animations 











