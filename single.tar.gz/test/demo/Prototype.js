var Prototype = {
    emptyFunction: function() { }
};

// var _ = require("../utils/underscore.js");

var ToolsClass = {
    //获取形参 name 的匹配
    argumentNames: function(obj) {
        var names = obj.toString().match(/^[\s\(]*function[^(]*\(([^\)]*)\)/)[1].replace(/\s+/g, '').split(',');
        return names.length == 1 && !names[0] ? [] : names;
    },

    bind: function(obj) {
        if (arguments.length < 2 && Object.isUndefined(arguments[0])) return obj;
        var __method = obj, args = $A(arguments), object = args.shift();
        return function() {
            return __method.apply(object, args.concat($A(arguments)));
        }
    },
    wrap: function(obj,wrapper) {
        var __method = obj;
        return function() {
            return wrapper.apply(this, [__method.bind(this)].concat($A(arguments)));
        }
    }

    // bind: function(obj) {
    //     if (arguments.length < 2 && Object.isUndefined(arguments[0])) return obj;
    //     var __method = obj, args = $A(arguments), object = args.shift();
    //     return function() {
    //         return __method.apply(object, args.concat($A(arguments)));
    //     }
    // },
    // wrap: function(obj,wrapper) {
    //     var __method = obj;
    //     return function() {
    //         var bindObj = ToolsClass.bind(obj);
    //         console.log(bindObj.tostring());
    //         return wrapper.apply(obj, [bindObj].concat($A(arguments)));
    //     }
    // }

    // bind: function() {
    //     if (arguments.length < 2 && Object.isUndefined(arguments[0])) return this;
    //     var __method = this, args = $A(arguments), object = args.shift();
    //     if(args.length == 0)
    //     {
    //         return this;
    //     }
    //     return function() {
    //         if(typeof(__method) != "function")
    //         {
    //             console.log("__method is not a function");
    //         }
    //         return __method.apply(object, args.concat($A(arguments)));
    //     }
    // },
    //  wrap: function(obj,wrapper) {
    //     var __method = obj;
    //     return function() {
    //         var arrParams = ToolsClass.bind(this);
    //         if(arrParams === this)
    //         {
    //             return wrapper.apply(this, $A(arguments));
    //         }else
    //         {
    //             console.log("warp  "+arrParams.toString());
    //             return wrapper.apply(this, [arrParams].concat($A(arguments)));
    //         }
    //     }
    // }
}

var Class = {
    create: function() {
        var parent = null, properties = $A(arguments);
        if (Object.isFunction(properties[0]))
            parent = properties.shift();
        function klass() {
            this.initialize.apply(this, arguments);
        }
        Object.extend(klass, Class.Methods);
        klass.superclass = parent;
        klass.subclasses = [];
        if (parent) {
            var subclass = function() { };
            subclass.prototype = parent.prototype;
            klass.prototype = new subclass;
            parent.subclasses.push(klass);
        }
        for (var i = 0; i < properties.length; i++)
            klass.addMethods(properties[i]);

        if (!klass.prototype.initialize)
            klass.prototype.initialize = Prototype.emptyFunction;
        klass.prototype.constructor = klass;
        return klass;
    }
};
// Class.Methods = {
//     addMethods: function(source) {
//         var ancestor = this.superclass && this.superclass.prototype;
//         var properties = Object.keys(source);
//         if (!Object.keys({ toString: true }).length)
//             properties.push("toString", "valueOf");
//         for (var i = 0, length = properties.length; i < length; i++) {
//             var property = properties[i], value = source[property];
//             if (ancestor && Object.isFunction(value) && value.argumentNames().first() == "$super") {
//                 var method = value;
//                 value = (function(m) {
//                     return function() { return ancestor[m].apply(this, arguments) };
//                 })(property).wrap(method);
//                 value.valueOf = method.valueOf.bind(method);
//                 value.toString = method.toString.bind(method);
//             }
//             this.prototype[property] = value;
//         }
//         return this;
//     }
// };

Class.Methods = {
    addMethods: function(source) {
        var ancestor = this.superclass && this.superclass.prototype;
        var properties = Object.keys(source);
        if (!Object.keys({ toString: true }).length)
            properties.push("toString", "valueOf");
        for (var i = 0, length = properties.length; i < length; i++) {
            var property = properties[i], value = source[property];
            if (ancestor && Object.isFunction(value) && ToolsClass.argumentNames(value).length > 0 && ToolsClass.argumentNames(value)[0] == "$super") {
                var method = value;

                var that = this;
                var targetObj = (function(m) {
                    return function() { return ancestor[m].apply(this, arguments) };
                })(property);
                value = ToolsClass.wrap(targetObj,method);
                // value = _.wrap(targetObj,method);

                value.valueOf = method.valueOf.bind(method);
                value.toString = method.toString.bind(method);
            }
            this.prototype[property] = value;
        }
        return this;
    }
};
/***
 * 把 source 中的 属性 复制到 destination 中
 */
Object.extend = function(destination, source) {
    for (var property in source)
        destination[property] = source[property];
    return destination;
};
/**
 * 返回 对 iterable 的复制数组对象
 *  */
function $A(iterable) {
    if (!iterable) return [];
    if (iterable.toArray) return iterable.toArray();
    var length = iterable.length || 0, results = new Array(length);
    while (length--) results[length] = iterable[length];
    return results;
}
Object.extend(Object, {
    keys: function(object) {
        var keys = [];
        for (var property in object)
            keys.push(property);
        return keys;
    },
    isFunction: function(object) {
        return typeof object == "function";
    },
    isUndefined: function(object) {
        return typeof object == "undefined";
    }
});
// Object.extend(Function.prototype, {
//     // argumentNames: function() {
//     //     var names = this.toString().match(/^[\s\(]*function[^(]*\(([^\)]*)\)/)[1].replace(/\s+/g, '').split(',');
//     //     return names.length == 1 && !names[0] ? [] : names;
//     // },
//     bind: function() {
//         if (arguments.length < 2 && Object.isUndefined(arguments[0])) return this;
//         var __method = this, args = $A(arguments), object = args.shift();
//         return function() {
//             return __method.apply(object, args.concat($A(arguments)));
//         }
//     },
//     wrap: function(wrapper) {
//         var __method = this;
//         return function() {
//             return wrapper.apply(this, [__method.bind(this)].concat($A(arguments)));
//         }
//     }
// });




// Object.extend(Array.prototype, {
//     first: function() {
//         // if(!this.hasOwnProperty("length"))
//         // {
//         //     console.log("lenth is 0");
//         // }
//         return this[0];
//     }
// });

module.exports = Class;