
var ResourceData= {
    Images:{
        //path：文件相对路径，picNum:当前图片中宽和高包含的小图片数，cellSize:小图片的宽和高，data：存放加载的图片数据。
        bg1:{path:"img/beijing.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:640,height:1136}, data:null}
        ,btn:{path:"img/btn.jpg", picNum:{WNum:1,HNum:1},cellSize:{width:469,height:204}, data:null}
        ,api:{path:"img/icon_API_HL.png", picNum:{WNum:1,HNum:1},cellSize:{width:40,height:40}, data:null}
        ,component:{path:"img/icon_component_HL.png", picNum:{WNum:1,HNum:1},cellSize:{width:40,height:40}, data:null}
        ,wechat:{path:"img/wechatHL.png", picNum:{WNum:1,HNum:1},cellSize:{width:40,height:40}, data:null}

        ,black_1:{path:"img/black_A.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_2:{path:"img/black_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_3:{path:"img/black_3.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_4:{path:"img/black_4.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_5:{path:"img/black_5.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_6:{path:"img/black_6.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_7:{path:"img/black_7.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_8:{path:"img/black_8.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_9:{path:"img/black_9.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_10:{path:"img/black_10.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_11:{path:"img/black_J.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_12:{path:"img/black_Q.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,black_13:{path:"img/black_K.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_1:{path:"img/red_A.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_2:{path:"img/red_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_3:{path:"img/red_3.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_4:{path:"img/red_4.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_5:{path:"img/red_5.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_6:{path:"img/red_6.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_7:{path:"img/red_7.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_8:{path:"img/red_8.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_9:{path:"img/red_9.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_10:{path:"img/red_10.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_11:{path:"img/red_J.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_12:{path:"img/red_Q.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,red_13:{path:"img/red_K.png", picNum:{WNum:1,HNum:1},cellSize:{width:27,height:36}, data:null}
        ,card:{path:"img/card.png", picNum:{WNum:1,HNum:1},cellSize:{width:128,height:168}, data:null}
        ,cardBg:{path:"img/cardBg.png", picNum:{WNum:1,HNum:1},cellSize:{width:74,height:98}, data:null}
        ,fangpian:{path:"img/fangpian.png", picNum:{WNum:1,HNum:1},cellSize:{width:70,height:66}, data:null}
        ,hongtao:{path:"img/hongtao.png", picNum:{WNum:1,HNum:1},cellSize:{width:70,height:66}, data:null}
        ,heitao:{path:"img/heitao.png", picNum:{WNum:1,HNum:1},cellSize:{width:70,height:66}, data:null}
        ,caohua:{path:"img/caohua.png", picNum:{WNum:1,HNum:1},cellSize:{width:70,height:66}, data:null}
        ,black_JOKER:{path:"img/black_JOKER.png", picNum:{WNum:1,HNum:1},cellSize:{width:26,height:149}, data:null}
        ,black_dizhu:{path:"img/black_dizhu.png", picNum:{WNum:1,HNum:1},cellSize:{width:26,height:149}, data:null}
        ,red_JOKER:{path:"img/red_JOKER.png", picNum:{WNum:1,HNum:1},cellSize:{width:77,height:108}, data:null}
        ,red_dizhu:{path:"img/red_dizhu.png", picNum:{WNum:1,HNum:1},cellSize:{width:77,height:108}, data:null}

        ,shuzi_1_0:{path:"img/font/shuzi_1_0.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_1:{path:"img/font/shuzi_1_1.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_2:{path:"img/font/shuzi_1_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_3:{path:"img/font/shuzi_1_3.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_4:{path:"img/font/shuzi_1_4.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_5:{path:"img/font/shuzi_1_5.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_6:{path:"img/font/shuzi_1_6.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_7:{path:"img/font/shuzi_1_7.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_8:{path:"img/font/shuzi_1_8.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}
        ,shuzi_1_9:{path:"img/font/shuzi_1_9.png", picNum:{WNum:1,HNum:1},cellSize:{width:33,height:39}, data:null}

        ,shuzi_2_0:{path:"img/font/shuzi_2_0.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_1:{path:"img/font/shuzi_2_1.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_2:{path:"img/font/shuzi_2_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_3:{path:"img/font/shuzi_2_3.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_4:{path:"img/font/shuzi_2_4.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_5:{path:"img/font/shuzi_2_5.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_6:{path:"img/font/shuzi_2_6.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_7:{path:"img/font/shuzi_2_7.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_8:{path:"img/font/shuzi_2_8.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_2_9:{path:"img/font/shuzi_2_9.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}

        ,shuzi_3_0:{path:"img/font/shuzi_3_0.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_1:{path:"img/font/shuzi_3_1.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_2:{path:"img/font/shuzi_3_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_3:{path:"img/font/shuzi_3_3.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_4:{path:"img/font/shuzi_3_4.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_5:{path:"img/font/shuzi_3_5.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_6:{path:"img/font/shuzi_3_6.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_7:{path:"img/font/shuzi_3_7.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_8:{path:"img/font/shuzi_3_8.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}
        ,shuzi_3_9:{path:"img/font/shuzi_3_9.png", picNum:{WNum:1,HNum:1},cellSize:{width:37,height:46}, data:null}

    },
    Sound:{
        //soundName:声音文件名称，path：文件夹相对路径，data：存放加载的声音数据。由于各种浏览器对声音格式的支持不一致，声音文件格式有MP3和OGG两种
        //sound01:{soundName:"sound01",path:"sound/", data:null,num:17}
    },
    Animation:{
         //ZS1_move:{imageName:"goddess_new",beginPoint:{WNum:0,HNum:0},allPlayNum:4,times:2}
    },
    UI:{
        //UI中的用图
        jiantou_1:{path:"img/jiantou_1.png", picNum:{WNum:1,HNum:1},cellSize:{width:638,height:225}, data:null}
        ,jiantou_2:{path:"img/jiantou_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:638,height:225}, data:null}
        ,banzi_1:{path:"img/banzi_1.png", picNum:{WNum:1,HNum:1},cellSize:{width:415,height:86}, data:null}
        ,banzi_2:{path:"img/banzi_2.png", picNum:{WNum:1,HNum:1},cellSize:{width:640,height:128}, data:null}
        ,icon_bei:{path:"img/icon_bei.png", picNum:{WNum:1,HNum:1},cellSize:{width:45,height:45}, data:null}
        ,button_m_buchu:{path:"img/button_m_buchu.png", picNum:{WNum:1,HNum:1},cellSize:{width:149,height:70}, data:null}
        ,button_m_chupai:{path:"img/button_m_chupai.png", picNum:{WNum:1,HNum:1},cellSize:{width:149,height:70}, data:null}
        // ,di:{path:"img/di.png", picNum:{WNum:1,HNum:1},cellSize:{width:45,height:45}, data:null}
        ,icon_dizhu:{path:"img/icon_dizhu.png", picNum:{WNum:1,HNum:1},cellSize:{width:56,height:56}, data:null}
        ,icon_jifen:{path:"img/icon_jifen.png", picNum:{WNum:1,HNum:1},cellSize:{width:45,height:45}, data:null}
        ,heidi:{path:"img/heidi.png", picNum:{WNum:1,HNum:1},cellSize:{width:163,height:36}, data:null}
        // ,jifen:{path:"img/jifen.png", picNum:{WNum:1,HNum:1},cellSize:{width:152,height:39}, data:null}
        ,button_tuoguan:{path:"img/button_tuoguan.png", picNum:{WNum:1,HNum:1},cellSize:{width:48,height:49}, data:null}
        ,button_liaotian:{path:"img/button_liaotian.png", picNum:{WNum:1,HNum:1},cellSize:{width:60,height:61}, data:null}
        ,button_shezhi:{path:"img/button_shezhi.png", picNum:{WNum:1,HNum:1},cellSize:{width:48,height:49}, data:null}
        ,button_m_tishi:{path:"img/button_m_tishi.png", picNum:{WNum:1,HNum:1},cellSize:{width:149,height:70}, data:null}
        ,touxiangkuang0:{path:"img/touxiangkuang0.png", picNum:{WNum:1,HNum:1},cellSize:{width:133,height:133}, data:null}
        ,toukuang1:{path:"img/toukuang1.png", picNum:{WNum:1,HNum:1},cellSize:{width:133,height:133}, data:null}
        ,toukuang2:{path:"img/toukuang2.png", picNum:{WNum:1,HNum:1},cellSize:{width:133,height:133}, data:null}
        ,touxiangdi:{path:"img/touxiangdi.png", picNum:{WNum:1,HNum:1},cellSize:{width:123,height:123}, data:null}
        // ,tuichu:{path:"img/tuichu.png", picNum:{WNum:1,HNum:1},cellSize:{width:56,height:57}, data:null}
        ,time:{path:"img/time.png", picNum:{WNum:1,HNum:1},cellSize:{width:146,height:146}, data:null}
        ,button_jilu:{path:"img/button_jilu.png"}
        ,button_l_haoyoutongwan:{path:"img/button_l_haoyoutongwan.png"}
        ,button_l_jixuyaoqinghaoyou:{path:"img/button_l_jixuyaoqinghaoyou.png"}
        ,button_l_jixuyouxi:{path:"img/button_l_jixuyouxi.png"}
        ,button_l_kaishiyouxi:{path:"img/button_l_kaishiyouxi.png"}
        ,button_l_mingpaikaishix:{path:"img/button_l_mingpaikaishix.png"}
        ,button_l_mingpaix:{path:"img/button_l_mingpaix.png"}
        ,button_l_quxiaotuoguan:{path:"img/button_l_quxiaotuoguan.png"}
        ,button_l_suijipipei:{path:"img/button_l_suijipipei.png"}
        ,button_l_yaoqinghaoyou:{path:"img/button_l_yaoqinghaoyou.png"}
        ,button_m_bujiabei:{path:"img/button_m_bujiabei.png"}
        ,button_m_bujiao:{path:"img/button_m_bujiao.png"}
        ,button_m_buqiang:{path:"img/button_m_buqiang.png"}
        ,button_m_jiabei:{path:"img/button_m_jiabei.png"}
        ,button_m_jiaodizhu:{path:"img/button_m_jiaodizhu.png"}
        ,button_m_mingpai:{path:"img/button_m_mingpai.png"}
        ,button_m_qiangdizhu:{path:"img/button_m_qiangdizhu.png"}
        ,button_m_queding:{path:"img/button_m_queding.png"}
        ,button_m_yaobuqi:{path:"img/button_m_yaobuqi.png"}
        ,button_tianjiahaoyou:{path:"img/button_tianjiahaoyou.png"}
        ,button_tishi:{path:"img/button_tishi.png"}
        ,chenghao_di:{path:"img/chenghao_di.png"}
        ,icon_jiabei:{path:"img/icon_jiabei.png"}
        ,icon_paishu1:{path:"img/icon_paishu1.png"}
        ,icon_paishu2:{path:"img/icon_paishu2.png"}
        ,icon_tuoguan:{path:"img/icon_tuoguan.png"}
        ,tishi_zhunbei:{path:"img/tishi_zhunbei.png"}
    }


};

module.exports = ResourceData